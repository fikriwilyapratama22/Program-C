/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: kereta api
**/

#include "stdio.h"

void main()
{
    int tujuan,kelas,jumlahtiket;
    long int harga,total;
    double disB,disC,pajak,setelahpajak,uang,kembalian;


    printf("\ntujuan kemana=");
    scanf("%i",&tujuan);
    printf("\nmasukkan kelas=");
    scanf("%i",&kelas);
    printf("\njumlah tiket=");
    scanf("%i",&jumlahtiket);

    switch(tujuan)
    {
    case 1:
        {
            switch(kelas)
            {
            case 1:
                {
                    printf("\n tujuan ke bandung");
                    harga = 10000;
                    total = harga*jumlahtiket;
                    printf("\n harga tiket ekonomi bandung == Rp. %li",harga);
                    printf("\n jumlah dibayar == Rp. %li",total);


                }break;
            case 2:
                 {
                    printf("\n tujuan ke bandung");
                    harga = 15000;
                    total = harga*jumlahtiket;
                    printf("\n harga tiket bisnis bandung == Rp. %li",harga);
                    printf("\n jumlah dibayar == Rp. %li",total);


                }break;
            case 3:
                 {
                    printf("\n tujuan ke bandung");
                    harga = 50000;

                    if(jumlahtiket>5)
                    {
                        disB=0.05*(harga*jumlahtiket);
                    }
                    else
                    {
                        disB=0;
                    }
                    total=(harga*jumlahtiket) - disB;

                    printf("diskon kelas ini ==Rp.%0.2lf",disB);
                    printf("\n harga tiket executive bandung == Rp. %li",harga);
                    printf("\n jumlah dibayar == Rp. %li",total);


                }break;
            default:
                printf("kelas salah");


            }


           }break;

    case 2:
        {
            switch(kelas)
            {
            case 1:
                {
                    printf("\n tujuan ke yogyakarta");
                    harga = 20000;
                    total = harga*jumlahtiket;
                    printf("\n harga tiket ekonomi bandung == Rp. %li",harga);
                    printf("\n jumlah dibayar == Rp. %li",total);


                }break;
            case 2:
                 {
                    printf("\n tujuan ke yogyakarta");
                    harga = 25000;
                    total = harga*jumlahtiket;
                    printf("\n harga tiket bisnis bandung == Rp. %li",harga);
                    printf("\n jumlah dibayar == Rp. %li",total);


                }break;
            case 3:
                 {
                    printf("\n tujuan ke yogyakarta");
                    harga = 75000;
                    total = harga*jumlahtiket;
                    printf("\n harga tiket executive bandung == Rp. %li",harga);
                    printf("\n jumlah dibayar == Rp. %li",total);


                }break;
            default:
                printf("kelas salah");


            }


           }break;

    case 3:
        {
            switch(kelas)
            {
            case 1:
                {
                    printf("\n tujuan ke surabaya");
                    harga = 30000;
                    total = harga*jumlahtiket;
                    printf("\n harga tiket ekonomi bandung == Rp. %li",harga);
                    printf("\n jumlah dibayar == Rp. %li",total);


                }break;
            case 2:
                 {
                    printf("\n tujuan ke surabaya");
                    harga = 35000;

                    if(jumlahtiket>10)
                    {
                        disC=0.1*(harga*jumlahtiket);
                    }
                    else
                    {
                        disC=0;
                    }
                    total=(harga*jumlahtiket)-disC;

                    printf("\n diskon kelas ini ==Rp.%0.2lf",disC);
                    printf("\n harga tiket bisnis bandung == Rp. %li",harga);
                    printf("\n jumlah dibayar == Rp. %li",total);


                }break;
            case 3:
                 {
                    printf("\n tujuan ke surabaya");
                    harga = 100000;
                    total = harga*jumlahtiket;
                    printf("\n harga tiket executive bandung == Rp. %li",harga);
                    printf("\n jumlah dibayar == Rp. %li",total);


                }break;
            default:
                printf("kelas salah");


            }


           }break;
            default:
                printf("pilihan tujuan salah");
    }
    pajak=0.1*total;
    setelahpajak=total+pajak;
    printf("\n pajak              ==Rp. %0.2lf",pajak);
    printf("\n ttl setelah pajak  ==Rp. %0.2lf",setelahpajak);

    printf("\nmasukkan jumlah pembayaran==");
    scanf("%lf",&uang);

    if(uang >= setelahpajak)
    {
        kembalian=uang-setelahpajak;
        printf("\nkembalian anda ==Rp. %0.2lf",kembalian);
    }
    else
    {
        kembalian=uang-setelahpajak;
        printf("\nduit kurang ==Rp. %0.2lf",kembalian);
    }
}

