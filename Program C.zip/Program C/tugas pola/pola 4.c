/** 5 5 5 5 5
    5 4 3 2 5
    5 4 3 2 5
    5 4 3 2 5
    5 5 5 5 5
**/
#include "stdio.h"
void main()
{
    int i,j,baris,kolom;

    printf("masukkan jumlah baris =");
    scanf("%i", &baris);
    printf("masukkan jumlah kolom =");
    scanf("%i", &kolom);

    for (i=1;i<=baris;i++)
    {
        for (j=kolom;j>=1;j--)
        {
           if (i==1 || i==5 || j==1 || j==5)
           {
               printf(" 5 ");
           }
           else
           {
               printf(" 2 ");
           }
        }
          printf("\n");
    }



}

