#include "stdio.h"
#include "stdlib.h"
void main()
{
    int A[100],i,n,z,x,idx;
    char ulang;

    srand(time(NULL));
    do{
        printf("ukuran array =");
        scanf("%i",&n);

        z=0;
        for(i=0;i<n;i++)
        {
            A[i]=rand()/10000;
        }
        printf("\nArray A =");
        for(i=0;i<n;i++)
        {
            printf(" %i",A[i]);
        }
        printf("\nmasukkan nilai x=");
        scanf("%i",&x);
          for(i=0;i<n;i++)
        {
            if(A[i]==x)
            {
               for(i=0;i<n;i++)
               {
                   if(x==A[i])
                   {
                    printf("\nnilai %i ada di indeks ke %i\n",x,i);
                   }

               }
                 printf("\n");
            }
        }

     /**   if(x!=A[i])
        {
            printf("tidak ada nilai ditemukan\n");
        } *//
      printf("\napakah ulang =");
      fflush(stdin);
      scanf("%c",&ulang);
    }while(ulang=='y'||ulang=='Y');
}

