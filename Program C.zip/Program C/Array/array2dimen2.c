#include <stdio.h>
#include <stdlib.h>

void main(){

    int A[100][100],B[100][100],C[100][100];
    int i,j,ba,ka,bb,kb,menu;
    char ulang;

     srand(time(NULL));
    do
    {


    printf("pilih menu GOAT=");
    scanf("%i",&menu);

    switch(menu)
    {
    case 1:
        {

                printf(" masukkan jumlah baris A=");
                scanf("%i",&ba);
                printf(" masukkan jumlah kolom A=");
                scanf("%i",&ka);
                printf(" masukkan jumlah baris B=");
                scanf("%i",&bb);
                printf(" masukkan jumlah kolom B=");
                scanf("%i",&kb);

                if(ba==bb && ka==kb)
                {
                printf("\n matriks A=\n");
                for(i=0;i<ba;i++)
                {
                    for(j=0;j<ka;j++)
                    {
                        printf("input nilai Array A indeks [%i][%i] = ",i,j);
                        scanf("%i",&A[i][j]);
                    }
                }
                printf("\n tampilan matriks A=\n");
                for(i=0;i<ba;i++)
                {
                    for(j=0;j<ka;j++)
                    {
                        printf("%i ",A[i][j]);

                    }
                    printf("\n");
                }
                printf("\n matriks B=\n");
                for(i=0;i<bb;i++)
                {
                    for(j=0;j<kb;j++)
                    {
                        B[i][j]=rand()/10000;
                    }
                }
                printf("\n tampilan matriks B=\n");
                for(i=0;i<bb;i++)
                {
                    for(j=0;j<kb;j++)
                    {
                        printf("%i ",B[i][j]);

                    }
                    printf("\n");
                }


                for(i=0;i<bb;i++)
                {
                    for(j=0;j<kb;j++)
                    {
                       C[i][j]= A[i][j]+B[i][j];

                    }
                    printf("\n");
                }
                printf("\n tampilan matriks C=\n");
                for(i=0;i<bb;i++)
                {
                    for(j=0;j<kb;j++)
                    {
                        printf("%i ",C[i][j]);

                    }
                    printf("\n");
                }


                }
                else
                {
                    printf("ukuran tidak sama");
                }
        }break;

    case 2 :
        {

                printf(" masukkan jumlah baris A=");
                scanf("%i",&ba);
                printf(" masukkan jumlah kolom A=");
                scanf("%i",&ka);
                printf(" masukkan jumlah baris B=");
                scanf("%i",&bb);
                printf(" masukkan jumlah kolom B=");
                scanf("%i",&kb);

                if(ba==bb && ka==kb)
                {
                printf("\n matriks A=\n");
                for(i=0;i<ba;i++)
                {
                    for(j=0;j<ka;j++)
                    {
                        printf("input nilai Array A indeks [%i][%i] = ",i,j);
                        scanf("%i",&A[i][j]);
                    }
                }
                printf("\n tampilan matriks A=\n");
                for(i=0;i<ba;i++)
                {
                    for(j=0;j<ka;j++)
                    {
                        printf("%i ",A[i][j]);

                    }
                    printf("\n");
                }
                printf("\n matriks B=\n");
                for(i=0;i<bb;i++)
                {
                    for(j=0;j<kb;j++)
                    {
                        B[i][j]=rand()/10000;
                    }
                }
                printf("\n tampilan matriks B=\n");
                for(i=0;i<bb;i++)
                {
                    for(j=0;j<kb;j++)
                    {
                        printf("%i ",B[i][j]);

                    }
                    printf("\n");
                }


                for(i=0;i<bb;i++)
                {
                    for(j=0;j<kb;j++)
                    {
                       C[i][j]= A[i][j]-B[i][j];

                    }
                    printf("\n");
                }
                printf("\n tampilan matriks C=\n");
                for(i=0;i<bb;i++)
                {
                    for(j=0;j<kb;j++)
                    {
                        printf("%i ",C[i][j]);

                    }
                    printf("\n");
                }


                }
                else
                {
                    printf("ukuran tidak sama");
                }
        }break;
    default:
        printf("menu salah");

    }
    printf("\napakah ulang == ");
    fflush(stdin);
    scanf("%c",&ulang);

    }while(ulang=='Y' || ulang=='y');

}
