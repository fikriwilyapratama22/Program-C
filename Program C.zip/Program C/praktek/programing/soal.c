/** Nama        : Basmida Laia
    No BP       : 2201091003
    Deskripsi   : soal
*/
#include "stdio.h"
void main()
{
    //inisialisasi variabel
    int a=12, b=2, c=3, d=4;

    //output
    printf("\n a%%b=%i", a%b);
    printf("\n a-c=%i", a-c);
    printf("\n a+b=%i", a+b);
    printf("\n a/d=%i", a/d);
    printf("\n a/d*d+a%%d=%i", a/d*d+a%d);
    printf("\n a%%d/d*a-c=%i", a%d/d*a-c);

}
