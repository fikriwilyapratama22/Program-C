#include "stdio.h"
void main()
{
    int i,a,b;
    long int fa,fb,perm;

    printf("masukkan nilai a =");
    scanf("%i",&a);

    printf("masukkan nilai b =");
    scanf("%i",&b);

    fa=1;
    for(i=1;i<=a;i++)
    {
        printf("%i",i);
        fa=fa*i;
    }
    printf("\ntotal =%li",fa);

    fb=1;
    for(i=1;i<=a-b;i++)
    {
        printf("%i",i);
        fb=fb*i;
    }
    printf("\ntotal fb =%li",fb);

    perm=fa/fb;
    printf("\npermutasi =%li",perm);
}
