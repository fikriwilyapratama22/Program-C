#include "stdio.h"
#include "stdlib.h"

void main()
{
    int A[100],B[100];
    int i,n,x;
    char ulang;

    srand (time (NULL));

    do{

        printf("masukkan ukuran array=");
        scanf("%i",&n);


        for(i=0;i<n;i++)
        {
            A[i]=rand()/1000;
        }
         for(i=0;i<n;i++)
        {
            printf(" %i", A[i]);
        }

        x=A[n-1];
          for(i=0;i<n;i++)
        {
           B[i+1]=A[i];
           B[0] =x;
        }
        printf("\narray B\n");

         for(i=0;i<n;i++)
        {
            printf(" %i", B[i]);
        }



       printf("\napakah ulang =");
       fflush(stdin);
       scanf("%c", &ulang);

    }while (ulang=='y' || ulang=='Y');
}

