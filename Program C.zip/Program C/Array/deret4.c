/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: deret fibonachi
**/

#include "stdio.h"

void main()
{
    int a,b,c,i,j,k,s;

    printf("jumlah baris=");
    scanf("%i",&b);
    printf("jumlah klm=");
    scanf("%i",&k);


    for(i=b;i>=1;i--)
    {

        for(s=b;s>=i;s--)
        {
            printf(" ");
        }
         for(j=i;j>=1;j--)
         if(i%2==0)
         {
             printf("%i",i);
         }
         else
         {
              printf("%i",j);
         }
         printf("\n");




   }
}

