/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: persegi panjang
**/

#include "stdio.h"

void main()
{
     int p,l,t,lab,vb,lpb,pilihan;




    printf("\nmenu balok:");
    printf("\n1.luas alas balok");
    printf("\n2.volume balok");
    printf("\n3. luas permukaan balok");
    printf("\npilih menu ==");
    scanf("%i",&pilihan);

    switch (pilihan)
    {
    case 1 :
        {
             printf("panjang==");
    scanf("%i",&p);
    printf("lebar==");
    scanf("%i",&l);
            lab=p*l;
            printf("\n luas alas balok = %i",lab);

        }break;
        case 2 :
        {
            printf("panjang==");
    scanf("%i",&p);
    printf("lebar==");
    scanf("%i",&l);
    printf("tinggi==");
    scanf("%i",&t);
            vb=p*l*t;
            printf("\n volume balok = %i",vb);
        }break;
        case 3 :
            {
                printf("panjang==");
    scanf("%i",&p);
    printf("lebar==");
    scanf("%i",&l);
    printf("tinggi==");
    scanf("%i",&t);


            lpb= (2*p*l) + (2*p*t) +( 2*l*t);
            printf("\n luas permukaan balok = %i",lpb);
    }break;
        default:
            printf("pilihan salah");
}
}
