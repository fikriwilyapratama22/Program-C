#include <stdio.h>
#include <stdlib.h>

main(){

    int b,n;
    int i,x;
    int t,C;
    char ulang;
    srand(time(NULL));

    do
    {


    printf("INPUT UKURAN : ");
    scanf("%d",&n);
      int *a = malloc(sizeof(int));
      int *d = malloc(sizeof(int));
      t = 0;


     for (i = 0;i < n; i++){
         a[i]=rand()/1000;
         }
    printf("\n");
    printf("NILAI ARRAY \n");


     for (i = 0;i < n; i++){
        printf("\t%d",a[i]);
        }
    printf("\nINPUT SEBUAH NILAI : ");
    scanf("%d",&x);
    printf("INPUT LOKASI LETAK NILAI : ");
    scanf("%d",&C);

     for (i = 0;i <= n; i++){
        if(C == 0){
            d[0] = x;
            d[i+1] = a[i];
        }

        else if(C ==1){
            d[1] = x;
            d[0]= a[0];
            d[i+1] = a[i];
        }

         else if(C ==2){
            d[2] = x;
            d[0]= a[0];
            d[1]=a[1];
            d[i+1] = a[i];
        }

         else if(C ==3){
            d[3] = x;
            d[0]= a[0];
            d[1]=a[1];
            d[2]=a[2];
            d[i+1] = a[i];
        }
        else if(C ==4){
            d[4] = x;
            d[0]= a[0];
            d[1]=a[1];
            d[2]=a[2];
            d[3]=a[3];
            d[i+1] = a[i];
        }
        else if(C ==5){
            d[5] = x;
            d[0]= a[0];
            d[1]=a[1];
            d[2]=a[2];
            d[3]=a[3];
            d[4]=a[3];
            d[i+1] = a[i];
        }
        d[C] = x;
        d[i+1] = a[i];




    }
    for (i = 0;i <= n; i++){
        printf("\t%d",d[i]);
    }

    int y;

    printf("\nMasukkan bilangan yang akan anda cari : ");
    scanf("%d",&y);


    for (i = 0; i <= n; i++){
        if (y == d[i]){
            printf("\nBilangan yang anda cari terletak pada indeks ke = %d",i);
        }
    }

    for (i = 0;i <= n; i++){
       t = t + d[i];
        }
    printf("\n===================================================");
    printf("\n\nHASIL PENJUMLAHAN ARRAY = %d",t);

    printf("\napakah ulang == ");
    fflush(stdin);
    scanf("%c",&ulang);

    }while(ulang=='Y' || ulang=='y');




}
