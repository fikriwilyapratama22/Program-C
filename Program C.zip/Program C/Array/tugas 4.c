/** Nama: Fikri Wilya Pratama
    Nim: 2201091017
*/

#include "stdio.h"

void main()
{
  float jarak,berat,biaya;

  printf("jarak =");
  scanf("%f",&jarak);
  printf("berat=");
  scanf("%f",&berat);

  jarak= (float)(jarak * 9000)/3;
  berat=(float) (berat * 4000)/2;
  biaya= (float) jarak + berat;

  printf("biaya = %f",biaya);






}
