#include <stdio.h>

void main()
{
    int i,j,n,t, A[100];
    srand(time(NULL));
    printf ("masukkan ukuran = ");
    scanf  ("%i",&n);
    for (i=0;i<n;i++)
    {
        A[i] = rand()/1000;
    }
    printf ("\nisi array  : ");
    for (i=0;i<n;i++)
    {
        printf (" %i ",A[i]);
    }
    for(i=0; i<n; i++)
    {
        for(j=n; j>=(i+1); j--)
        {
            if(A[j-1]>A[j])
            {
                t=A[j-1];
                A[j-1] = A[j];
                A[j] = t;
            }
        }
    }

    printf("\nUrutannya adalah : ");
    for(i=0; i<n; i++)
    {
        printf(" %d ", A[i]);
    }
    printf("\n");
    return 0;
}

