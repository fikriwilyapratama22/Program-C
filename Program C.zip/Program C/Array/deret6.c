/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: deret
**/

#include "stdio.h"

void main()
{
    int a,b,c,i,j,k;

    printf("jumlah baris=");
    scanf("%i",&b);
    printf("jumlah klm=");
    scanf("%i",&k);

    for(i=1;i<=b;i++)
    {
        for(j=1;j<=i;j++)
        {
          printf("  ");
        }
        for(c=b-1;c>=i;c--)
        {
            printf("* ");
        }
        for(a=1;a<=i;a++)
        {
            printf("* ");
        }

        printf("\n");
    }
}
