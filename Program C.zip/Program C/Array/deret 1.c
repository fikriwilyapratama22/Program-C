/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: pola
**/

#include "stdio.h"

void main()
{
    int a,b,c,j,i,k;


    a=0;
    j=1;
    k=1;

    printf("jumlah baris=");
    scanf("%i",&b);
    printf(" %i",a);
    printf(" %i",j);


    for(i=0;i<=b;i++)
    {
        c=a+j;
        printf(" %i ", c);

       k=k+c;

       a=j;

       j=c;
    }
}

