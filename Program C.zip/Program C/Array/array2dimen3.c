#include <stdio.h>
#include <stdlib.h>

void main(){

    int A[100][100];
    int i,j,ba,ka,bb,kb,p;


    srand(time(NULL));
    printf(" masukkan jumlah baris A=");
    scanf("%i",&ba);
    printf(" masukkan jumlah kolom A=");
    scanf("%i",&ka);



    printf("\n matriks A=\n");
    for(i=0;i<ba;i++)
    {
        for(j=0;j<ka;j++)
        {
            A[i][j]=rand()/10000;
        }
    }
    printf("\n tampilan matriks A=\n");
    for(i=0;i<ba;i++)
    {
        for(j=0;j<ka;j++)
        {
            printf("%i ",A[i][j]);

        }
        printf("\n");
    }
    printf("\n matriks A=\n");
    for(i=0;i<ba;i++)
    {
        for(j=0;j<ka;j++)
        {
          p=i;
          i=j;
          j=p;
        }
    }
    printf("\n tampilan matriks A=\n");
    for(i=0;i<ka;i++)
    {
        for(j=0;j<ba;j++)
        {
            printf("%i ",A[j][i]);

        }
        printf("\n");
    }
}

