/** Nama: Fikri Wilya Pratama
    Nim: 2201091017
*/

#include "stdio.h"

void main()
{
    int pena,pensil,buku,spidol,hargapena,hargapensil,hargabuku,hargaspidol,totalsemua,hasil;
    float pajak;



    printf("masuk pena=");
    scanf("%i",& pena);
    printf("masuk pensil=");
    scanf("%i",& pensil);
    printf("masuk buku=");
    scanf("%i",& buku);
    printf("masuk spidol=");
    scanf("%i",& spidol);

    hargapena = pena * 3500;
    hargapensil = pensil * 4000;
    hargabuku = buku * 5500;
    hargaspidol = spidol * 6250;
    totalsemua= (hargabuku + hargapensil + hargapena + hargaspidol);
    pajak=((float) (10 * totalsemua)/100);
    hasil= totalsemua + pajak;

    printf("\ntotal semua = %i", totalsemua);
    printf("\npajak = %f",pajak);
    printf("\nsetelah pajak =%i",hasil);





}
