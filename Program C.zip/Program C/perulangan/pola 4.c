/** Nama        : Linus dimbau
    NIM         : 2201091008
    Deskripsi   : pola 1

    1 1 1 1
    2 2 2 2
    3 3 3 3
    4 4 4 4
*/
#include "stdio.h"
void main ()
{
    int i,j,b,k,n;

    printf("Masukkan jumlah baris =");
    scanf("%i", &b);
    printf("Masukkan jumlah kolom =");
    scanf("%i", &k);

    for (i=1;i<=b;i++)
    {
        for (n=b;n>=1;n--)
        {
            printf(" ~ ");
        }
        for (j=1;j<=i;j++);
        {
            printf(" * ");
        }
        printf("\n");
    }

}
