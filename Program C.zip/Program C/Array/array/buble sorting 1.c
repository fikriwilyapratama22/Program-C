#include <stdio.h>

void main()
{
    int i,j,n,t, A[100];
    printf ("masukkan batas array = ");
    scanf ("%i",&n);

    for (i=0;i<n;i++)
    {
        printf ("masukan nilai array indeks ke %i = ",i);
        scanf  ("%i",&A[i]);
    }
    printf ("\n isi array a : ");
    for (i=0;i<n;i++)
    {
        printf (" %i ",A[i]);
    }
    for(i=0; i<n; i++)
    {
        for(j=n; j>=(i+1); j--)
        {
            if(A[j-1]>A[j])
            {
                t=A[j-1];
                A[j-1] = A[j];
                A[j] = t;
            }
        }
    }

    printf("\nUrutannya adalah : ");
    for(i=0; i<n; i++)
    {
        printf(" %d ", A[i]);
    }
    printf("\n");
    return 0;
}
