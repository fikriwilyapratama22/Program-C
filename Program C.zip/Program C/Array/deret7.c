/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: pola
**/

#include "stdio.h"

void main()
{
    int a,b,c,j,i,k;


    a=1;


    printf("jumlah baris=");
    scanf("%i",&b);

    for(i=1;i<=b;i++)
    {
        if(i%3==1)
        {

            printf(" %i ", a);
              a=a+1;

        }
        if(i%3==2)
        {

            printf(" %i ",a);
            a=a+2;
        }
        if(i%3==0)
        {

            printf(" %i ", a);
            a=a+3;
        }

    }
}




