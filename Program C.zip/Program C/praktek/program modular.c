#include "stdio.h"

 long int luas(int a, int b);

 void main()
 {
     int p,l;
     long int L;
     printf("masukkan Panjang= ");
     scanf("%i",&p);
      printf("masukkan lebar= ");
     scanf("%i",&l);
     L= luas(p,l);
     printf("luas persegi = %li", L);


 }
long int luas(int a, int b)
{
    long int hasil;
    hasil=a*b;
    return(hasil);
}
