/** Nama        : Linus Dimbau
    NIM         : 2201091008
    Deskripsi   : ongkos kirim barang
*/
#include "stdio.h"
void main()
{
    float jarak,berat,biaya;

    printf("masukkan jarak =");
    scanf("%f", &jarak);
    printf("masukkan berat=");
    scanf("%f", &berat);

    jarak=(float)jarak*3000;
    berat =(float)berat*2000;
    biaya=jarak+berat;

    printf("biaya=%f", biaya);
}
