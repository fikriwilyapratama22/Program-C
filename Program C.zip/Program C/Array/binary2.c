#include <stdio.h>
#include <stdlib.h>

void main()
{
    int A[100],a,b,n,x,i,z,idx;
    char ulang;

    srand(time(NULL));

    do
    {
    printf ("masukkan nilai n = ");
    scanf  ("%i",&n);
    z=0;
    i=0;
    while (i<n)
    {
        A[i]=rand()/10000;
        i++;
    }
    printf("Array A==");
    i=0;
    while (i<n)
    {
        printf(" %i ",A[i]);
        i++;
    }

    printf ("\nmasukkan nilai  = ");
    scanf  ("%i",&x);
    i=0;
    while(i<n&&A[i]!=x)
    {
        if(A[i]==x)
        {
       i++;


        }

    }
    if(A[i]==x)
    {

        printf("\nBilangan  yang anda cari ada pada indeks %i ==",i);
    }
    else
    {
        printf("\ntidak ada");
    }


    printf("\napakah ulang == ");
    fflush(stdin);
    scanf("%c",&ulang);

    }while(ulang=='Y' || ulang=='y');
}

