#include "stdio.h"

void main()
{
    float dolar;
    long int div,mod,rupiah,pecahan100rb,pecahan50rb,pecahan10rb,pecahan5rb,pecahan2rb,pecahan500;

    printf("dolar =");
    scanf("%f",&dolar);

    rupiah= dolar * 14000;
    div= rupiah/100000;






    printf("\n total rupiah = %li",rupiah);
    printf("\n pecahan100rb = %li",pecahan100rb);


}
