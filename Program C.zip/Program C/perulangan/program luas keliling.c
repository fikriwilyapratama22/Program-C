#include "stdio.h"
void main()
{
    int panjang,lebar;
    long int luas,keliling;

    printf("masukkan panjang =");
    scanf("%i", &panjang);
    printf("masukkan lebar =");
    scanf("%i", &lebar);

    luas=panjang*lebar;
    keliling=2*(panjang+lebar);

    printf("\nluas persegi panjang=%li", luas);
    printf("\nkeliling persegi panjang=%li", keliling);
}
