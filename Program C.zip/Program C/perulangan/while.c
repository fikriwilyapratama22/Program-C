#include "stdio.h"
void main ()
{
    int i=0,n,total=0;

    while (n!=0)
    {
        printf("mahasiswa =");
        scanf("%i", &n);
        total=total=n;
        i++;
    }
    printf("total semuanya adalah %i\n", total);
}
