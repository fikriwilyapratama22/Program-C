/** Nama        : Basmida Laia
    NIM         : 2201091003
    Deskripsi   : Gaji Pegawai
*/
#include "stdio.h"
void main()
{
    int golongan,jam,anak;
    long int gajipokok,gaji_jam,gaji_lembur,totalgaji;
    double pajak,setpajak;

    printf("pilih menu golongan=");
    scanf("%i", &golongan);
    printf("masukkan jam kerja =");
    scanf("%i", &jam);
    printf("jumlah anak        =");
    scanf("%i", &anak);

    switch (golongan)
    {
    case 1 :
        {
            if (jam>10)
            {
                gajipokok=50000;
                gaji_jam=5000*10;
                gaji_lembur=(jam-10)*10000;
                printf("\ngaji pokok        =%li", gajipokok);
                printf("\ngaji per jam      =%li", gaji_jam);
                printf("\ngaji lembur       =%li", gaji_lembur);
                if (anak<=3)
                {
                    anak=35000*anak;
                    totalgaji=gajipokok+gaji_jam+gaji_lembur+anak;
                }
                else
                {
                    anak=35000*3;
                    totalgaji=gajipokok+gaji_jam+gaji_lembur+anak;
                }
                printf("\ntunjangan anak           =%li", anak);
                printf("\ntotal gaji sebelum pajak =%li", totalgaji);
            }
            else
            {
                gajipokok=50000;
                gaji_jam=5000*jam;
                gaji_lembur=0;
                printf("\ngaji pokok        =%li", gajipokok);
                printf("\ngaji per jam      =%li", gaji_jam);
                printf("\ngaji lembur       =%li", gaji_lembur);
                if (anak<=3)
                {
                    anak=35000*anak;
                    totalgaji=gajipokok+gaji_jam+gaji_lembur+anak;
                }
                else
                {
                    anak=35000*3;
                    totalgaji=gajipokok+gaji_jam+gaji_lembur+anak;
                }
                printf("\ntunjangan anak             =%li", anak);
                printf("\ntotal gaji sebelum pajak   =%li", totalgaji);
            }
            pajak=0.05*totalgaji;
            setpajak=totalgaji-pajak;
            printf("\nDikenakan pajak          =%.2lf", pajak);
            printf("\ntotal gaji setelah pajak =%.2lf", setpajak);

        }break;
    case 2 :
        {
            if (jam>10)
            {
                gajipokok=70000;
                gaji_jam=6000*10;
                gaji_lembur=(jam-10)*15000;
                printf("\ngaji pokok        =%li", gajipokok);
                printf("\ngaji per jam      =%li", gaji_jam);
                printf("\ngaji lembur       =%li", gaji_lembur);
                if (anak<=3)
                {
                    anak=35000*anak;
                    totalgaji=gajipokok+gaji_jam+gaji_lembur+anak;
                }
                else
                {
                    anak=35000*3;
                    totalgaji=gajipokok+gaji_jam+gaji_lembur+anak;
                }
                printf("\ntunjangan anak           =%li", anak);
                printf("\ntotal gaji sebelum pajak =%li", totalgaji);
            }
            else
            {
                gajipokok=70000;
                gaji_jam=6000*jam;
                gaji_lembur=0;
                printf("\ngaji pokok        =%li", gajipokok);
                printf("\ngaji per jam      =%li", gaji_jam);
                printf("\ngaji lembur       =%li", gaji_lembur);
                if (anak<=3)
                {
                    anak=35000*anak;
                    totalgaji=gajipokok+gaji_jam+gaji_lembur+anak;
                }
                else
                {
                    anak=35000*3;
                    totalgaji=gajipokok+gaji_jam+gaji_lembur+anak;
                }
                printf("\ntunjangan anak             =%li", anak);
                printf("\ntotal gaji sebelum pajak   =%li", totalgaji);
            }
            pajak=0.05*totalgaji;
            setpajak=totalgaji-pajak;
            printf("\nDikenakan pajak          =%.2lf", pajak);
            printf("\ntotal gaji setelah pajak =%.2lf", setpajak);

        }break;
    case 3 :
        {
            if (jam>10)
            {
                gajipokok=100000;
                gaji_jam=7000*10;
                gaji_lembur=(jam-10)*20000;
                printf("\ngaji pokok        =%li", gajipokok);
                printf("\ngaji per jam      =%li", gaji_jam);
                printf("\ngaji lembur       =%li", gaji_lembur);
                if (anak<=3)
                {
                    anak=35000*anak;
                    totalgaji=gajipokok+gaji_jam+gaji_lembur+anak;
                }
                else
                {
                    anak=35000*3;
                    totalgaji=gajipokok+gaji_jam+gaji_lembur+anak;
                }
                printf("\ntunjangan anak           =%li", anak);
                printf("\ntotal gaji sebelum pajak =%li", totalgaji);
            }
            else
            {
                gajipokok=100000;
                gaji_jam=7000*jam;
                gaji_lembur=0;
                printf("\ngaji pokok        =%li", gajipokok);
                printf("\ngaji per jam      =%li", gaji_jam);
                printf("\ngaji lembur       =%li", gaji_lembur);
                if (anak<=3)
                {
                    anak=35000*anak;
                    totalgaji=gajipokok+gaji_jam+gaji_lembur+anak;
                }
                else
                {
                    anak=35000*3;
                    totalgaji=gajipokok+gaji_jam+gaji_lembur+anak;
                }
                printf("\ntunjangan anak             =%li", anak);
                printf("\ntotal gaji sebelum pajak   =%li", totalgaji);
            }
            pajak=0.1*totalgaji;
            setpajak=totalgaji-pajak;
            printf("\nDikenakan pajak          =%.2lf", pajak);
            printf("\ntotal gaji setelah pajak =%.2lf", setpajak);
        }break;
    default :
        printf("pilihan golongan salah");
    }
}
