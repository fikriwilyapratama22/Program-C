/** Nama: Fikri Wilya Pratama
    Nim: 2201091017
*/

#include "stdio.h"

void main()
{
    long int jamawal,jamakhir,menitawal,menitakhir,detikawal,detikakhir,totaldetik;
    float bayar;


    printf("jam awal=");
    scanf("%li",&jamawal);
    printf("menit awal=");
    scanf("%li",&menitawal);
    printf("detik awal=");
    scanf("%li",&detikawal);
    printf("jam akhir=");
    scanf("%li",&jamakhir);
    printf("menit akhir");
    scanf("%li",&menitakhir);
    printf("detik akhir");
    scanf("%li",&detikakhir);

    jamawal = jamawal * 3600;
    menitawal = menitawal * 60;
    detikawal = detikawal;
    jamakhir = jamakhir * 3600;
    menitakhir = menitakhir * 60;
    detikakhir = detikakhir;

    totaldetik = (jamakhir + menitakhir + detikakhir) - (jamawal + menitawal + detikawal);
    bayar = (totaldetik/500)*200;

    printf("\n total = %li",totaldetik);
    printf("\n bayar = %f",bayar);









}

