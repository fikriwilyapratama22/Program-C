#include "stdio.h"
void main()
{
    int jam,menit,det;
    long int detik,sisajam;

    printf("masukkan total detik =");
    scanf("%li", &detik);

    jam=detik / 3600;
    sisajam= detik%3600;
    menit=sisajam/60;
    det=sisajam%60;

    printf("%i jam : %i menit : %i detik", jam,menit,det);

}
