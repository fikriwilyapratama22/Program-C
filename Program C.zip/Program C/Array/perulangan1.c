/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: perulangan angka
**/

#include "stdio.h"

void main()
{
    int i;
    int na,nk;

    printf("masukkan nilai awal==");
    scanf("%i",&na);
    printf("masukkan nilai akhir==");
    scanf("%i",&nk);

    for(i=na; i<=nk; i++)
    {
        if((i % 2==1) && ( i %3==0))
        printf(" %i",i);
    }
}
