#include "stdio.h"

int tambah(int x,int y);
float bagi(int n,int m);
void main()
{
    int a,b,tamb;
    printf("masukkan nialai a =");
    scanf("%i",&a);
    printf("masukkan nialai b =");
    scanf("%i",&b);

    printf("\n%i + %i = %i",a,b,tambah(a,b));
    printf("\n%i - %i = %i",a,b,kurang(a,b));
    printf("\n%i / %i = %.2f",a,b,bagi(a,b));
}
int tambah(int x,int y)
{
    int hasil;
    hasil=x+y;
    return(hasil);
}
int kurang(int n,int m)
{
    int hasil1;
    hasil1=n-m;
    return(hasil1);
}
float bagi(int n,int m)
{
    float hasil1;
    hasil1=n/m;
    return(hasil1);
}

