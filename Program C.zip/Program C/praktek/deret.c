/** buatlah pemrograman dari deret berikut
    ha hi hi hi ha hi ha hi hi hi ha hi ha hi hi hi ha hi ha hi hi hi ha
*/
#include "stdio.h"
void main()
{
    int i,nk;

    printf("masukkan nilai akhir =");
    scanf("%i", &nk);

    for (i=1;i<=nk;i++);
    {
        if (i%2==0 || i%3==0)
        {
            printf("hasilnya = hi");
        }
        else
        {
            printf("hasilnya = ha");
        }
    }
}
