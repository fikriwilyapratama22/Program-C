#include "stdio.h"

void main()
{
    int a,b,c,j,i,k,n,total;
    i=1;


    while(n>0)
    {
    printf("mahasiswa %i=",i);
    scanf("%i",&n);
    i++;

    }


}


