#include <stdio.h>
#include <stdlib.h>

void main()
{
    int a[100],b[100];
    int n, i, j, k, c, d;
    char ulang;
    do{
    srand(time(NULL));
    printf ("menu");
    printf ("\n1. delete indeks dalam array");
    printf ("\n2. tambah nilai dalam array");
    printf ("\n3. geser kiri");
    printf ("\n4. geser kanan");
    printf ("\nmasukkan menu = ");
    scanf  ("%i",&k);
    printf ("\npilihan");
    printf ("\n1. input random");
    printf ("\n2. input oleh user");
    printf ("\npilihan = ");
    scanf  ("%i",&c);



    switch (k)
    { case 1 :

      switch (c)
    {
        case 1 : printf ("\nmasukkan ukuran = ");
                 scanf  ("%i",&n);
                 for(i=0;i<n;i++)
                 {
                     a[i] = rand()/1000;

                 }
                 for(i=0;i<n;i++)
                 {
                     printf("  %i",a[i]);
                 }
                 j=0;
                 for (i=0;i<n;i++)
                 {

                     a[j]= a[i + 1];
                     j++;
                 }
                 printf ("\n isi array a sekarang : ");
                 for (i=0;i<j-1;i++)
                 {
                      printf (" %i ",a[i]);
                 }break;

       case 2 : printf ("masukkan batas array = ");
                scanf ("%i",&n);
                for (i=0;i<n;i++)
                {
                     printf ("masukan nilai array indeks ke %i = ",i);
                     scanf  ("%i",&a[i]);
                }
                     printf ("\n isi array a : ");
                     for (i=0;i<n;i++)
                {
                     printf (" %i ",a[i]);
                }
                j=0;
                for (i=0;i<n;i++)
                {
                     a[j]= a[i + 1];
                     j++;
                }
                printf ("\n isi array a sekarang : ");
                for (i=0;i<j-1;i++)
                {
                    printf (" %i ",a[i]);
                }break;

    }break;
      case 2 :
        switch (c)
    {
        case 1 : printf ("\nmasukkan ukuran = ");
                 scanf  ("%i",&n);
                 printf ("masukkan nilai tambahan = ");
                 scanf ("%i",&d);
                 for(i=0;i<n;i++)
                 {
                     a[i] = rand()/1000;

                 }
                 for(i=0;i<n;i++)
                 {
                     printf("  %i",a[i]);
                 }
                 for (i=0;i<n;i++)
                 {

                     b[i+1]= a[i];
                     b[0]=d;

                }
                     printf ("\n isi array a sekarang : ");
                for (i=0;i<n+1;i++)
                {

                     printf (" %i ", b[i]);
                } break;

       case 2 : printf ("masukkan batas array = ");
                scanf ("%i",&n);
                printf ("masukkan nilai tambahan = ");
                scanf ("%i",&d);
                for (i=0;i<n;i++)
                {
                     printf ("masukan nilai array indeks ke %i = ",i);
                     scanf  ("%i",&a[i]);
                }
                     printf ("\n isi array a : ");
                     for (i=0;i<n;i++)
                {
                     printf (" %i ",a[i]);
                }
                for (i=0;i<n;i++)
                 {

                     b[i+1]= a[i];
                     b[0]=d;

                }
                     printf ("\n isi array a sekarang : ");
                for (i=0;i<n+1;i++)
                {

                     printf (" %i ", b[i]);
                } break;

    }break;

    case 3 :
        switch (c)
    {
        case 1 : printf ("\nmasukkan ukuran = ");
                 scanf  ("%i",&n);
                 for(i=0;i<n;i++)
                 {
                     a[i] = rand()/1000;

                 }
                 for(i=0;i<n;i++)
                 {
                     printf("  %i",a[i]);
                 }
                 d=a[n-1];
                 for (i=0;i<n;i++)
                 {
                    b[i+1]=a[i];
                    b[0]=d;
                 }
                 printf ("\n isi array a sekarang : ");
                 for (i=0;i<n;i++)
                 {

                     printf (" %i ", b[i]);
                 }break;

       case 2 : printf ("masukkan batas array = ");
                scanf ("%i",&n);
                for (i=0;i<n;i++)
                {
                     printf ("masukan nilai array indeks ke %i = ",i);
                     scanf  ("%i",&a[i]);
                }
                     printf ("\n isi array a : ");
                for (i=0;i<n;i++)
                {
                     printf (" %i ",a[i]);
                }
                d=a[n-1];
                for (i=0;i<n;i++)
                {
                    b[i+1]=a[i];
                    b[0]=d;
                }
                printf ("\n isi array a sekarang : ");
                for (i=0;i<n;i++)
                {
                     printf (" %i ", b[i]);
                }break;

    }break;


            case 4 :
        switch (c)
    {
        case 1 : printf ("\nmasukkan ukuran = ");
                 scanf  ("%i",&n);
                 for(i=0;i<n;i++)
                 {
                     a[i] = rand()/1000;

                 }
                 for(i=0;i<n;i++)
                 {
                     printf("  %i",a[i]);
                 }
                 d=a[0];
                 for (i=0;i<n;i++)
                 {

                     b[i]= a[i+1];
                     b[n-1]=d;

                 }
                     printf ("\n isi array a sekarang : ");
                     for (i=0;i<n;i++)
                 {

                     printf (" %i ", b[i]);
                 }break;

       case 2 : printf ("masukkan batas array = ");
                scanf ("%i",&n);
                for (i=0;i<n;i++)
                {
                     printf ("masukan nilai array indeks ke %i = ",i);
                     scanf  ("%i",&a[i]);
                }
                     printf ("\n isi array a : ");
                     for (i=0;i<n;i++)
                {
                     printf (" %i ",a[i]);
                }
                 d=a[0];
                 for (i=0;i<n;i++)
                 {

                     b[i]= a[i+1];
                     b[n-1]=d;

                 }
                     printf ("\n isi array a sekarang : ");
                     for (i=0;i<n;i++)
                 {

                     printf (" %i ", b[i]);
                 }break;


    }break;


    }



    printf("\n Apakah mau mengulang ==");
    fflush(stdin);
    scanf("%c",&ulang);
    system("cls");
}
    while(ulang=='Y'|| ulang=='y');

}

