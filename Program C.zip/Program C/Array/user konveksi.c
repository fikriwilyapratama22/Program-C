#include "stdio.h"

void main()
{
    int detik,jam,menit,div,mod,b;

    printf("detik=");
    scanf("%i",&detik);



    div=detik/3600;
    mod=detik%3600;
    menit=mod/60;
    b= mod%60;

    printf("\n jam= %i",div);
    printf("\n menit=%i",menit);
    printf("\n detik=%i",b);

}
