/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: persegi panjang
**/

#include "stdio.h"

void main()
{
     int p,l,kll,luas;
     char pilihan;

    printf("panjang==");
    scanf("%i",&p);
    printf("lebar==");
    scanf("%i",&l);

    printf("\nmenu persegi panjang:");
    printf("\n1.luas persegi panjang");
    printf("\n2.kll persegi panjang");
    printf("\npilih menu a/b==");
    fflush(stdin);
    scanf("%c",&pilihan);

    switch (pilihan)
    {
    case 'a':
        {
             luas=p*l;
        printf("\n luas persegi panjang=%i",luas);

        }break;
    case 'b':
        {
            (kll=2*(p+l));
        printf("\n keliling persegi panjang=%i",kll);
    }break;
    default:
        printf("pilihan menu salah");
        }
    }








