#include "stdio.h"
#include "stdlib.h"

void main()
{
    int A[100];
    int B[100];
    int i,n,b;
    char ulang;

    srand(time(NULL));

    do{

        printf("masukkan ukuran array=");
        scanf("%i",&n);

        for(i=0;i<n;i++)
        {
            A[i]=rand()/1000;
        }

        for(i=0;i<n;i++)
        {
            printf(" %i",A[i]);
        }
        b=A[n-1];
        for(i=0;i<n;i++)
        {
           B[i+1]=A[i];
           B[0]=b;
        }
        printf("\n array B \n");



        for(i=0;i<n;i++)
        {
            printf(" %i",B[i]);
        }



        printf("\n apakah ulang==");
        fflush(stdin);
        scanf("%c",&ulang);

    }while(ulang=='y'||ulang=='Y');



}


