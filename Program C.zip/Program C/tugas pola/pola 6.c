/** 1  2  3  4  5
    6  7  8  9  10
    11 12 13 14 15
    13 17 18 19 20
    21 22 23 25 25
**/
#include "stdio.h"
void main()
{
    int i,j,baris,a,kolom;

    printf("masukkan jumlah baris =");
    scanf("%i", &baris);
    printf("masukkan jumlah kolom =");
    scanf("%i", &kolom);

    for (i=1;i<=baris;i++)
    {
        for (j=1;j<=kolom;j++)
        {
            a=a+1;
           printf(" %i ",a);
        }
          printf("\n");
    }



}

