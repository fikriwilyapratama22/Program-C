/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: do while 1
**/

#include "stdio.h"

void main()
{
    int i,ulang;

    do
    {





    i=2;
    do
    {
        if(i%2==0)
        {
            printf(" %i ", i);
            i=i+2;
        }


    }while(i<=10);

    printf("\n ulang kah=");
    scanf("%i",&ulang);

    }while(ulang==1 || ulang==0);

}
