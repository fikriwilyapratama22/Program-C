/**  1 1 1 1 1
     1 1 1 1 1
     1 1 1 1 1
     1 1 1 1 1
**/
#include "stdio.h"
void main()
{
    int i,j,baris,kolom;

    printf("masukkan jumlah baris =");
    scanf("%i", &baris);
    printf("masukkan jumlah kolom =");
    scanf("%i", &kolom);

    for (i=1;i<=baris;i++)
    {
        for (j=1;j<=kolom;j++)
        {
            printf(" 1 ");
        }
          printf("\n");
    }



}
