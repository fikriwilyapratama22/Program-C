#include "stdio.h"

#define JUDUL "basmidalaia imut.com"
#define BILANGAN 100
void main()
{
    int usia;
    float ipk;
    char nama[20];


    printf("masukkan nama anda : ");
    scanf ("%[^\n]s", nama);
    printf("masukkan usia anda :");
    scanf("%i", &usia);
    printf("berapa ipk anda :");
    scanf("%f", &ipk);

    printf("\n\nnama anda adalah : %s", nama);
    printf("\nUsia anda adalah : %i tahun", usia);
    printf("\nipk anda adalah : %.1f", ipk);







}
