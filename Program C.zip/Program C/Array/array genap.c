#include "stdio.h"
#include "stdlib.h"

void main()
{
    int A[100];
    int B[100];
    int C[100];
    int i,n,b,j,x;
    char ulang;

    srand(time(NULL));

    do{

        printf("masukkan ukuran array=");
        scanf("%i",&n);

        for(i=0;i<n;i++)
        {
          scanf("%i",&A[i]);
        }
        printf("\narray A=");

        for(i=0;i<n;i++)
        {
            printf(" %i ", A[i]);
        }

        for(i=0;i<=n;i++)
        {


         B[i]=rand()/1000;

        }

        printf("\narray B=");
        for(i=0;i<n;i++)
        {
            printf(" %i",B[i]);
        }


             for(i=0;i<n;i++)
             {
                  if(A[i] %2==0 && B[i] %2==0 || A[i] %2==1 && B[i] %2==1 )
                  {
                      C[i]=A[i]+B[i];
                  }
                  else
                  {
                      C[i]=A[i]-B[i];
                  }
             }
        printf("\narray C=");
        for(i=0;i<n;i++)
        {
            printf(" %i",C[i]);
        }





        printf("\n apakah ulang==");
        fflush(stdin);
        scanf("%c",&ulang);

    }while(ulang=='y'||ulang=='Y');



}



