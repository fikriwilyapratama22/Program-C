/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: iterasi faktorial permutasi kombinasi
**/

#include "stdio.h"

void main()
{
    int i,j,b,k,a,n,m;

    printf("jumlah baris=");
    scanf("%i",&b);
    printf("jumlah klm=");
    scanf("%i",&k);



    for(i=1;i<=b;i++)
    {
         for(n=b;n>=i;n--)
        {
            printf("   ");
        }

        for(j=1;j<=i;j++)
        {
            printf(" *    ");
        }
        printf("\n");
    }

         for(i=2;i<=b;i++)
    {
         for(n=1;n<=i;n++)
        {
            printf("   ");
        }

        for(j=b;j>=i;j--)
        {
            printf(" *    ");
        }
         printf("\n");
}
    }

















