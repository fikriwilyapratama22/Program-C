/** 1 1 1 1 1
    2 2 2 2 2
    3 3 3 3 3
    4 4 4 4 4
    5 5 5 5 5
**/
#include "stdio.h"
void main()
{
    int i,j,baris,kolom;

    printf("masukkan jumlah baris =");
    scanf("%i", &baris);
    printf("masukkan jumlah kolom =");
    scanf("%i", &kolom);

    for (i=1;i<=baris;i++)
    {
        for (j=1;j<=kolom;j++)
        {
            printf(" %i ",i);
        }
          printf("\n");
    }



}
