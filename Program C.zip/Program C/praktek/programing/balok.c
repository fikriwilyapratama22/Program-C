#include "stdio.h"
void main()
{
    int panjang,lebar,tinggi,luasalas,volumebalok,luaspermukaanbalok,pilihmenu;


    printf("\npilih menu :");
    printf("\n1. Luas alas balok");
    printf("\n2. volume balok");
    printf("\n3. luas permukaan balok");
    printf("\npilih menu =");
    scanf("%i", &pilihmenu);

    switch (pilihmenu)
    {
    case 1 :
        {
            printf("panjang =");
            scanf("%i", &panjang);
            printf("lebar =");
            scanf("%i", &lebar);
            luasalas=panjang*lebar;
            printf("Luas ala balok =%i", luasalas);
        }break;
    case 2 :
        {
            printf("panjang =");
            scanf("%i", &panjang);
            printf("lebar =");
            scanf("%i", &lebar);
            printf("tinggi =");
            scanf("%i", &tinggi);
            volumebalok=panjang*lebar*tinggi;
            printf("volume balok =%i", volumebalok);
        }break;
    case 3 :
        {
            printf("panjang =");
            scanf("%i", &panjang);
            printf("lebar =");
            scanf("%i", &lebar);
            printf("tinggi =");
            scanf("%i", &tinggi);
            luaspermukaanbalok=(2*panjang+lebar)+(2*panjang*tinggi)+(2*lebar*tinggi);
            printf("luas permukaan balok =%i", luaspermukaanbalok);
        }break;
    default :
        printf("pilihan menu salah");
    }
}
