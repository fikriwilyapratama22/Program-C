/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: deret fibonachi
**/

#include "stdio.h"

void main()
{
    int a,b,c,i,j,k,s;

    printf("jumlah baris=");
    scanf("%i",&b);
    printf("jumlah klm=");
    scanf("%i",&k);


    for(i=1;i<=b;i++)
    {

         for(j=1;j<=i;j++)
         {
             printf("*");
         }
         for(c=4;c>=i;c--)
         {
             printf("k");
         }
         for(a=b-1;a>=i;a--)
         {
             printf("k");
         }
         for(s=1;s<=i;s++)
         {
             printf("*");
         }
         printf("\n");



   }


}


