#include <stdio.h>

void main()
{
    int a[10],b[10],c[10];
    int i,n;
    printf ("masukkan batas array = ");
    scanf ("%i",&n);
    for (i=0;i<n;i++)
    {
        printf ("masukan nilai array indeks ke %i = ",i);
        scanf  ("%i",&a[i]);
    }
    printf ("\nisi array a : ");
    for (i=0;i<n;i++)
    {
        printf (" %i ",a[i]);
    }
    for (i=0;i<n;i++)
    {
        printf ("\n masukan nilai array indeks ke %i = ",i);
        scanf  ("%i",&b[i]);
    }
    printf ("\nisi array b : ");
    for (i=0;i<n;i++)
    {
        printf (" %i ",b[i]);
    }

    for (i=0;i<n;i++)
    {
        c[i]= a[i]+b[i];
    }
    printf("\nisi array c : ");
    for (i=0;i<n;i++)
    {
        printf (" %i ",c[i]);
    }


}
