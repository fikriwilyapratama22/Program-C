#include "stdio.h"

///deklarasi fungsi
int tambah(int x,int y);
long int kurang(int x,int y);
int div (int x,int y);

float bagi(int z, int w)
{
  float hasil1;
  hasil1 = z/w;
  return(hasil1);
}

int mod(int z,int s)
{
    int hasil;
    hasil = z%s;
    return(hasil);
}

void main()
{
  int a,b,tamb,modulo;
  printf("masukan nilai a=");
  scanf("%i",&a);
  printf("masukan nilai b=");
  scanf("%i",&b);
  printf("\n%i  + %i = %i",a,b,tambah(a,b));
  printf("\n%i  - %i = %li",a,b,kurang(a,b));
  printf("\n%i  : %i = %0.2f",a,b,bagi(a,b));
  modulo = mod(a,b);
  printf("%i mod %i = %i",a,b,modulo);
  printf("\n%i  div %i = %i",a,b,div(a,b));

}

int tambah(int x,int y)
{
    int hasil;
    hasil= x+y;
    return(hasil);
}

long int kurang(int x,int y)
{
    int hasil;
    hasil = x-y;
    return(hasil);
}

int div (int x,int y)
{
    return(x/y);
}


