/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: pola
**/

#include "stdio.h"

void main()
{
    int i,j,b,k;

    printf("jumlah baris=");
    scanf("%i",&b);
    printf("jumlah klm=");
    scanf("%i",&k);


    for(i=1;i<=b;i++)
    {
        for(j=1;j<=k;j++)
        {
            printf(" %i ",i);
        }
        printf("\n");
    }
}

