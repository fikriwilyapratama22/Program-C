#include "stdio.h"
#include "stdlib.h"
void main()
{
    int A[100][100],B[100][100];
    int i,j,ba,ka,bb,kb,c;

    printf("masukkan jumlah baris a =");
    scanf("%i",&ba);
    printf("masukkan jumlah kolom a =");
    scanf("%i",&ka);


    printf("\nmatriks A =\n");
    for(i=0;i<ba;i++)
    {
        for(j=0;j<ka;j++)
        {
            A[i][j]=rand()/10000;
        }
    }
    printf("\ntampilan A =\n");
    for(i=0;i<ba;i++)
    {
        for(j=0;j<ka;j++)
        {
            printf(" %i",A[i][j]);
        }
        printf("\n");
    }
     for(i=0;i<ba;i++)
    {
        for(j=0;j<ka;j++)
        {
           c=i;
           i=j;
           j=c;

        }
    }
    printf("\ntampilan A =\n");
    for(i=0;i<ka;i++)
    {
        for(j=0;j<ba;j++)
        {
          printf(" %i",A[j][i]);
        }
        printf("\n");
    }


}

