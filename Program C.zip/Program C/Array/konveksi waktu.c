/** Nama: Fikri Wilya Pratama
    Nim: 2201091017
    Deskripsi: konversi waktu
*/




#include "stdio.h"

void main()
{
    int jam,menit,detik,total;


    printf("jam=");
    scanf("%i",&jam);
    printf(" menit=");
    scanf("%i",&menit);
    printf("detik=");
    scanf("%i",&detik);

    jam= jam * 3600;
    menit= menit * 60;
    detik= detik;
    total = jam + menit + detik;

    printf("\n Jam = %i",jam);
    printf("\n Menit = %i",menit);
    printf("\n Detik = %i",detik);
    printf("\n Total = %i",total);


}


