#include "stdio.h"

long int kubus(int s);
long int balok(int p, int l, int t);
long int bola(int r);
long int tabung(int r, int t);
long int kerucut(int r, int t);
long int limas(int la, int t);

  long int kubus(int s)
{
    long int hasil;
    hasil=pow(s,3);
    return(hasil);

}
 long int balok(int p, int l, int t)
{
    long int hasil;
    hasil=p*l*t;
    return(hasil);
}
 long int bola(int r)
{
    long int hasil;
    hasil=4/3*3.14*pow(r,3);
    return(hasil);
}
long int kerucut(int r, int t)
{
    long int hasil;
    hasil=0.3*3.14*r*r*t;
    return(hasil);
}
long int limas(int la, int t)
{
    long int hasil;
    hasil=0.3*la*t;
    return(hasil);
}
long int tabung(int r, int t)
{
    long int hasil;
    hasil=3.14*r*r*t;
    return(hasil);
}
 void main()
 {

     int s,p,l,t,menu,la,r;
     char ulang;

     printf("pilih menu =");
     scanf("%i",&menu);



      switch(menu)
{
case 1 :
    {
     printf("masukkan nilai s= ");
     scanf("%i",&s);
     printf("volume kubus=%li",kubus(s));
    }break;
case 2 :

    {
     printf("\nmasukkan nilai p= ");
     scanf("%i",&p);
     printf("\nmasukkan nilai l= ");
     scanf("%i",&l);
     printf("\nmasukkan nilai t= ");
     scanf("%i",&t);
     printf("volume balok=%li",balok(p,l,t));
    }break;

case 3 :

    {
     printf("\nmasukkan nilai r= ");
     scanf("%i",&r);

     printf("volume balok=%li",bola(r));
    }break;
case 4 :

    {
     printf("\nmasukkan nilai r= ");
     scanf("%i",&r);
     printf("\nmasukkan nilai t= ");
     scanf("%i",&t);
     printf("volume tabung=%li",tabung(r,t));
    }break;
case 5 :

    {
     printf("\nmasukkan nilai r= ");
     scanf("%i",&r);
     printf("\nmasukkan nilai t= ");
     scanf("%i",&t);
     printf("volume balok=%li",kerucut(r,t));
    }break;
case 6 :

    {
     printf("\nmasukkan nilai r= ");
     scanf("%i",&r);
     printf("\nmasukkan nilai t= ");
     scanf("%i",&t);
     printf("volume balok=%li",limas(r,t));
    }break;



default:
printf("pilihan menu tidak ada");
}


 }

