#include <stdio.h>

void main()
{
    int a[10];
    int i;
    for (i=0;i<10;i++)
    {
        printf ("masukan nilai array A indeks ke %i = ",i);
        scanf  ("%i",&a[i]);
    }
    for (i=0;i<10;i++)
    {
        printf (" %i ",a[i]);
    }
}
