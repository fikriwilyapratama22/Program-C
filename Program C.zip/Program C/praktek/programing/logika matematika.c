/** Nama      : Basmida Laia
    No BP     : 2201091003
    Prodi     : D-3 Manajemen informatika
    Deskripsi : Logika Matematika

*/
#include "stdio.h"

void main()
{
    int angka_1,angka_2,kali,tambah,kurang,div,mod;
    float bagi;

    angka_1 = 113;
    angka_2 = 7;
    kali = angka_1*angka_2;
    bagi = (float)angka_1/angka_2;
    tambah = angka_1+angka_2;
    kurang = angka_1-angka_2;
    div = angka_1/angka_2;
    mod = angka_1%angka_2;

    printf("\nangka_1 adalah = %i", angka_1);
    printf("\nangka_2 adalah = %i", angka_2);
    printf("\nHasil kali =%i", kali);
    printf("\nHasil bagi =%.2f", bagi);
    printf("\nHasil tambah = %i", tambah);
    printf("\nHasil kurang = %i", kurang);
    printf("\nHasil div = %i", div);
    printf("\nHasil mod = %i", mod);
}



