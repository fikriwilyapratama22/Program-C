#include "stdio.h"
#include "stdlib.h"
void main()
{
    int A[100],i,n,z,x,idx;
    char ulang;

    srand(time(NULL));
    do{
        printf("ukuran array =");
        scanf("%i",&n);


        z=0;
        i=0;
        while(i<n)
        {
            A[i]=rand()/10000;
            i++;
        }
        printf("\nArray A =");
          i=0;
        while(i<n)
        {
            printf(" %i",A[i]);
            i++;
        }
        printf("\nmasukkan nilai x=");
        scanf("%i",&x);
          i=0;
        while(i<n)
        {
            if(A[i]==x)
            {
                z=1;
                idx=i;

            }
            i++;
        }
        if(z==1)
        {
            printf("Ada");
            printf("\nnilai %i ditemukan dalam indeks ke %i",x,idx);
        }
        else
        {
            printf("tidak ada");
        }




      printf("\napakah ulang =");
      fflush(stdin);
      scanf("%c",&ulang);
    }while(ulang=='y'||ulang=='Y');
}
