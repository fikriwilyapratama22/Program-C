#include "stdio.h"

#define TEMA "Hidup tanpa kepahitan"
#define ANGKA 100

void main()
{

    int angka = 12;
    char huruf = 'b';
    float pecahan = 12.05;

    printf("konstanta TEMA adalah %s\n", TEMA);
    printf("konstanta angka adalah %i\n", ANGKA);

    printf("variabel angka adalah = %i\n", angka);
    printf("variabel huruf adalah = %c\n", huruf);
    printf("variabel pecahan adalah = %.2f\n", pecahan);




}
