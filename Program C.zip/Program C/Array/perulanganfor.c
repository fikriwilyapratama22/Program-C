/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: iterasi faktorial permutasi kombinasi
**/

#include "stdio.h"

void main()
{
    int angka1,angka2,a,b,i,fa,fb,c,menu;



    printf("1. kombinasi\n");
    printf("2. permuntasi\n");
    printf("3. kombinasi\n");


    printf("pilih menu==\n");
    scanf("%i",&menu);

    printf("masukkan angka1==\n");
    scanf("%i",&angka1);
    printf("masukkan angka2==\n");
    scanf("%i",&angka2);



    switch(menu)
    {
    case 1:
            {

                fa=1;
                for(i=1;i<=a;i++)
                {
                    fa=fa*i;
                }
                printf("\nnilai faktorial %i = %i",a,fa);

                fb=1;
                for(i=1;i<=b;i++)
                {
                    fb=fb*i;
                }
                printf("\nnilai faktorial %i = %i",b,fb);
            }break;
    }


}
