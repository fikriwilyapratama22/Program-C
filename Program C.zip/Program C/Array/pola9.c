/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: pola9
**/

#include "stdio.h"

void main()
{
    int i,j,b,k,a;

    printf("jumlah baris=");
    scanf("%i",&a);




    b=1;
    for(i=1;i<=a;i++)
    {


        printf( " %i ", b);
           b=b*2;



    }


}

