/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: persegi panjang
**/

#include "stdio.h"

void main()
{
    int waktu,pelanggan,biaya;

    printf("\npelanggan:");
    printf("\n1.VIP");
    printf("\n2.Tetap");
    printf("\n3. Biasa");
    printf("\npilih menu ==");
    scanf("%i",&pelanggan);


    printf("biaya admin = 5000");
    printf("pemakaian 3 jam pertama tarif 3000/jam");
    printf("pemakaian berikutnya biaya 2000/jam");
    printf("waktu= ");
    scanf("%i",&waktu);


    switch (pelanggan)
    {
    case 1 :
        {
            biaya= waktu * 2000;
            printf("biaya = %i",biaya);
        }break;
        case 2 :
            {

                    if ( waktu <= 3)

                {
                    biaya= waktu * 2000;
            printf("biaya = %i",biaya);
                }


                else
                {
                    biaya= (3 * 3000) + ((waktu - 3) *2000);
                }



            }break;
            case 3
            {

                    if ( waktu <= 3)

                {
                    biaya= waktu * 2000;
            printf("biaya = %i",biaya);
                }


                else
                {
                    biaya= (3 * 3000) + ((waktu - 3) *2000);
                }



            }break;









}
}
