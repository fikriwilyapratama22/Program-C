
#include <stdio.h>

void main()
{
    int a[10];
    int i,n;
    printf ("masukkan batas array = ");
    scanf ("%i",&n);
    for (i=0;i<n;i++)
    {
        printf ("masukan nilai array A indeks ke %i = ",i);
        scanf  ("%i",&a[i]);
    }
    for (i=0;i<n;i++)
    {
        printf (" %i ",a[i]);
    }
}
