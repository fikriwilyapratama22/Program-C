#include "stdio.h"
#include "stdlib.h"
void main()
{
    int A[100][100],B[100][100];
    int i,j,ba,ka,bb,kb;

    printf("masukkan jumlah baris a =");
    scanf("%i",&ba);
    printf("masukkan jumlah kolom a =");
    scanf("%i",&ka);
    printf("masukkan jumlah baris b =");
    scanf("%i",&bb);
    printf("masukkan jumlah baris b =");
    scanf("%i",&kb);

    printf("\nmatriks A =\n");
    for(i=0;i<ba;i++)
    {
        for(j=0;j<ka;j++)
        {
            printf("input nilai array A indeks [%i][%i]=",i,j);
            scanf("%i",&A[i][j]);
        }
    }
    printf("\ntampilan A =\n");
    for(i=0;i<ba;i++)
    {
        for(j=0;j<ka;j++)
        {
            printf(" %i",A[i][j]);
        }
        printf("\n");
    }
    printf("\nmatriks B =\n");
    for(i=0;i<bb;i++)
    {
        for(j=0;j<kb;j++)
        {
            B[i][j]=rand()/10000;
        }
    }
    printf("\ntampilan B =\n");
    for(i=0;i<bb;i++)
    {
        for(j=0;j<kb;j++)
        {
            printf(" %i",B[i][j]);
        }
        printf("\n");
    }
}
