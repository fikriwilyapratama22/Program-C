#include <stdio.h>

void main()
{
    int a[10],b[10],c[10];
    int i,n,j,d;
    printf ("masukkan batas array = ");
    scanf ("%i",&n);
    printf ("masukkan nilai tambahan = ");
    scanf ("%i",&d);
    for (i=0;i<n;i++)
    {
        printf ("masukan nilai array indeks ke %i = ",i);
        scanf  ("%i",&a[i]);
    }
    printf ("\n isi array a : ");
    for (i=0;i<n;i++)
    {
        printf (" %i ",a[i]);
    }

    for (i=0;i<n;i++)
    {

        b[i+1]= a[i];
        b[0]=d;

    }
    printf ("\n isi array a sekarang : ");
    for (i=0;i<n+1;i++)
    {

        printf (" %i ", b[i]);
    }

}
