/** Nama      : Basmida Laia
    No BP     : 2201091003
    Prodi     : D-3 Manajemen informatika
    Deskripsi : Logika Matematika

*/
#include "stdio.h"
void main()
{
    int keranjang_A;
    int keranjang_B;
    int keranjang_C;
    keranjang_A = 20;
    keranjang_B = 30;

    printf("\nsebelum ditukar");
    printf("\nisi dari keranjang_A = %i", keranjang_A);
    printf("\nisi dari keranjang_B = %i", keranjang_B);

    keranjang_C=keranjang_A;
    keranjang_A=keranjang_B;
    keranjang_B=keranjang_C;

    printf("\n\nsesudah ditukar");
    printf("\nisi dari keranjang_A = %i", keranjang_A);
    printf("\nisi dari keranjang_B = %i", keranjang_B);



}
