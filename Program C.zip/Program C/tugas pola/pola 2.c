/**  1 2 3 4 5
     1 2 3 4 5
     1 2 3 4 5
     1 2 3 4 5
**/
#include "stdio.h"
void main()
{
    int i,j,baris,kolom;

    printf("masukkan jumlah baris =");
    scanf("%i", &baris);
    printf("masukkan jumlah kolom =");
    scanf("%i", &kolom);

    for (i=1;i<=baris;i++)
    {
        for (j=1;j<=kolom;j++)
        {
            printf(" %i ",j);
        }
          printf("\n");
    }



}
