/** 1 2 3 4 5
    2 2 2 2 2
    1 2 3 4 5
    4 4 4 4 4
    1 2 3 4 5
**/
#include "stdio.h"
void main()
{
    int i,j,baris,a,kolom;

    printf("masukkan jumlah baris =");
    scanf("%i", &baris);
    printf("masukkan jumlah kolom =");
    scanf("%i", &kolom);

    for (i=1;i<=baris;i++)
    {
        for (j=1;j<=kolom;j++)
        {
         if (i%2==0)
         {
             printf(" %i ", i);
         }
         else
         {
             printf(" %i ", j);
         }
        }
          printf("\n");
    }



}


