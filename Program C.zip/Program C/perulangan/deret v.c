#include "stdio.h"
void main()
{
    int i,j,b,c,m,n,k;

    printf("masukkan baris =");
    scanf("%i", &b);
    printf("masukkan kolom =");
    scanf("%i", &k);


    for (i=1;i<=b;i++)
    {
        for (j=1;j<=i;j++)
        {
            printf(" * ");
        }
        for (c=b-1;c>=i;c--)
        {
            printf("   ");
        }
        for (m=b-1;b>=i;m--)
        {
            printf("   ");
        }
        for (n=1;n<=i;n++)
        {
            printf(" * ");
        }
       printf("\n");
    }
}
