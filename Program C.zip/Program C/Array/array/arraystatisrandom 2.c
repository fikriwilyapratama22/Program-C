#include <stdio.h>
#include <stdlib.h>


void main()
{
    int A[100];
    int n, i;
    char ulang;
    do{
    srand(time(NULL));
    n = rand()/100;

    for(i=0;i<n;i++)
    {
        A[i] = rand()/1000;

    }
    for(i=0;i<n;i++)
    {
        printf("  %i",A[i]);
    }

    printf("\n Apakah mau mengulang ==");
    fflush(stdin);
    scanf("%c",&ulang);
    system("cls");
}
    while(ulang=='Y'|| ulang=='y');

}
