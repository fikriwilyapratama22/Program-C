#include <stdio.h>
#include <stdlib.h>

main(){

    int b,n;
    int i,x;
    int t;
    srand(time(NULL));
    printf("INPUT UKURAN : ");scanf("%d",&n);//memasukkan batas array
      int *a = malloc(sizeof(int));
      int *d = malloc(sizeof(int));
      t = 0;

     //input nilai secara automatis
     for (i = 0;i < n; i++){
         a[i]=rand()/1000;
         }
    printf("\n");
    printf("NILAI ARRAY \n");

    //menampilkan array
     for (i = 0;i < n; i++){
        printf("\t%d",a[i]);
        }
    printf("\nINPUT SEBUAH NILAI : ");scanf("%d",&x); //menambahkan nilai ke dalam array

     for (i = 0;i <= n; i++){
        d[0] = x;
        d[i + 1] = a[i];
        }
    for (i = 0;i <= n; i++){
        printf("\t%d",d[i]);
    }

    int y;

    printf("\nMasukkan bilangan yang akan anda cari : ");scanf("%d",&y);

    //mencari nilai berada pada indeks ke
    for (i = 0; i <= n; i++){
        if (y == d[i]){
            printf("\nBilangan yang anda cari terletak pada indeks ke = %d",i);
        }
    }
    //menjumlahkan nilai dalam array
    for (i = 0;i <= n; i++){
       t = t + d[i];
        }
    printf("\n===================================================");
    printf("\n\nHASIL PENJUMLAHAN ARRAY = %d",t);




}
