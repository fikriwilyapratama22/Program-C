/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: iterasi faktorial permutasi kombinasi
**/

#include "stdio.h"

void main()
{
    int i,j,b,k;

    printf("jumlah baris=");
    scanf("%i",&b);
    printf("jumlah klm=");
    scanf("%i",&k);


    for(i=1;i<=1;i++)
    {
        for(j=k;j>=1;j--)
        {
            printf(" %i ",j);
        }
        printf("\n");
    }
}

