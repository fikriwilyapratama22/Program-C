#include "stdio.h"
void main()
{
  int i=0, N, jumlah=0,j;

while( N!=0 )
{
    printf("Masukkan Bilangan : ");
    scanf("%d",&N);
    jumlah = jumlah + N;
    i++;
}
    printf("Jumlahnya adalah %d\n", jumlah);

}
