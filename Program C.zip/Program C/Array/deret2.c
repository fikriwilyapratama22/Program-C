/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: deret
**/

#include "stdio.h"

void main()
{
    int a,b,c,i,j,k;

    printf("jumlah baris=");
    scanf("%i",&b);
    printf("jumlah klm=");
    scanf("%i",&k);

    for(i=1;i<=b;i++)
    {
        for(j=1;j<=i;j++)
        if(i%4==3 || i%4==0)
        {
            printf(" %i ",i);

        }
        else
        {
            printf(" %i ",j);
        }

        printf("\n");
    }
}
