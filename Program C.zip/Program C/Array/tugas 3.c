/** Nama: Fikri Wilya Pratama
    Nim: 2201091017
*/

#include "stdio.h"

void main()
{
    int jams,jama,jami,kompensasi;

    printf("jam sakit=");
    scanf("%i",&jams);
    printf("jam izin=");
    scanf("%i",&jami);
    printf("jam alfa=");
    scanf("%i",&jama);

    jams = jams * 0;
    jami = jami * 1;
    jama = jama * 2;
    kompensasi = (jams + jami + jama);


    printf("\nkompensasi= %i",kompensasi);
}
