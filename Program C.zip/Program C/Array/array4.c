#include "stdio.h"
#include "stdlib.h"

void main()
{
    int A[100];
    int B[100];
    int i,n,menu,j;
    char ulang;

    srand(time(NULL));



    do{

        printf("pilih menu banh=");
        scanf("%i",&menu);

    switch(menu)
    {
            case 1 :
                {
                    printf("masukkan ukuran array=");
                    scanf("%i",&n);

                    for(i=0;i<n;i++)
                    {
                        A[i]=rand()/1000;
                    }

                    for(i=0;i<n;i++)
                    {
                        printf(" %i",A[i]);
                    }

                    for(i=0;i<n;i++)
                    {
                        B[i]=A[i];

                    }
                    printf("\narray B\n");

                    for(i=0;i<n;i++)
                    {
                        printf(" %i",B[i]);
                    }
                }break;
            case 2 :
                {
                    printf("masukkan ukuran array=");
                    scanf("%i",&n);

                    for(i=0;i<n;i++)
                    {
                        A[i]=rand()/1000;
                    }

                    for(i=0;i<n;i++)
                    {
                        printf(" %i",A[i]);
                    }

                    j=n-1;

                    for(i=0;i<n;i++)
                    {
                        B[i]=A[j];
                        j=j-1;

                    }
                     printf("\narray B\n");

                    for(i=0;i<n;i++)
                    {
                        printf(" %i",B[i]);
                    }
                }break;

              case 3 :
                {
                    printf("masukkan ukuran array=");
                    scanf("%i",&n);
                    j=n;
                    for(i=0;i<n;i++)
                    {
                        A[i]=rand()/1000;
                    }

                    for(i=0;i<n;i++)
                    {
                        printf(" %i",A[i]);
                    }

                    j=0;

                    for(i=0;i<n;i++)
                    {
                       if(A[i] % 2==0)
                       {
                           B[j]=A[i];
                           j=j+1;                       }


                    }
                     printf("\narray B\n");

                    for(i=0;i<j;i++)
                    {
                        printf(" %i",B[i]);
                    }
                }break;

    }



        printf("\n apakah ulang==");
        fflush(stdin);
        scanf("%c",&ulang);

    }while(ulang=='y'||ulang=='Y');



}






