#include "stdio.h"
#include "stdlib.h"
void main()
{
    int A[100],B[100],i,j,n,x,total;
    char u;
    srand(time(NULL));
    do{
        printf("masukkan ukuran array=");
        scanf("%i",&n);
       for(i=0;i<n;i++)
       { A[i]=rand()/1000;}
       printf("\narray A =");
       for(i=0;i<n;i++)
       { printf(" %i", A[i]);}
       printf("\nmasukkan nilai x =");
       scanf("%i",&x);
       j=0;
        for(i=0;i<n+1;i++)
       {       B[j+1]=A[i];
               j=j+1;
               A[0]=x;
               A[i]=B[i];
       }
       total=0;
       printf("\narray B =");
       for(i=0;i<j;i++)
       {
           printf(" %i",A[i]);
           total=total+A[i];
       }
        printf("\ntotal hasil tambah =%i",total);
    printf("\napakah ulang =");
    fflush(stdin);
    scanf("%c",&u);
    }while(u=='y'||u=='Y');
}




