#include "stdio.h"

void main()
{
    int angka1, angka2,tambah, kurang, kali, div, mod;
    float bagi;

    printf("masukan angka1 =");
    scanf("%i",&angka1);
    printf("masukan angka2 =");
    scanf("%i",&angka2);

    tambah= angka1 + angka2;
    kurang= angka1 - angka2;
    kali= angka1 * angka2;
    bagi= (float) angka1/angka2;
    div= angka1/angka2;
    mod= angka1 % angka2;

    printf("\n %i + %i = %i",angka1,angka2,tambah);
    printf("\n %i - %i = %i",angka1,angka2,kurang);
    printf("\n %i * %i = %i",angka1,angka2,kali);
    printf("\n %i : %i = %0.1f",angka1,angka2,bagi);
    printf("\n %i div %i = %i",angka1,angka2,div);
    printf("\n %i mod %i = %i",angka1,angka2,mod);
}
