#include "stdio.h"
void main()
{
    char ulang;
    do{

    typedef struct
    {
        int pg,pt,m,k;

    }pecahan,menu ;
    pecahan p1,p2,p3;
    menu m1;


    printf("pilih menu =");
    scanf("%i", &m1.m);


    printf("pembilang =");
    scanf("%i",&p1.pg);
    printf("penyebut =");
    scanf("%i",&p1.pt);
    printf("pembilang kedua =");
    scanf("%i",&p2.pg);
    printf("penyebut kedua =");
    scanf("%i",&p2.pt);




    switch(m1.m)
    {
    case 1:
        {
            printf("\n%i/%i",p1.pg,p1.pt );
            printf(" + %i/%i =",p2.pg,p2.pt );
            if (p1.pt!=p2.pt && p1.pt<p2.pt )
            {

                p3.pt=p1.pt*p2.pt;
                p1.pg=(p3.pt/p1.pt)*p1.pg;
                p3.pg=p1.pg+p2.pg;
                printf("%i/%i + %i/%i =%i/%i",p1.pg,p1.pt,p2.pg,p2.pt,p3.pg,p3.pt);
            }
            else if(p1.pt!=p2.pt && p1.pt>p2.pt)
            {
                p3.pt=p1.pt*p2.pt;
                p2.pg=(p3.pt/p2.pt)*p2.pg;
                p3.pg=p1.pg+p2.pg;
                printf("%i/%i + %i/%i =%i/%i",p1.pg,p1.pt,p2.pg,p2.pt,p3.pg,p3.pt);
            }
            else
            {
                p3.pg=p1.pg+p2.pg;
                p3.pt=p1.pt;
                printf("%i/%i + %i/%i =%i/%i",p1.pg,p1.pt,p2.pg,p2.pt,p3.pg,p3.pt);

            }
        }break;
    case 2:
        {
            printf("\n%i/%i",p1.pg,p1.pt );
            printf(" - %i/%i =",p2.pg,p2.pt );
            if (p1.pt!=p2.pt && p1.pt<p2.pt )
            {
                p3.pt=p1.pt*p2.pt;
                p1.pg=(p3.pt/p1.pt)*p1.pg;
                p3.pg=p1.pg-p2.pg;
                printf("%i/%i - %i/%i =%i/%i",p1.pg,p1.pt,p2.pg,p2.pt,p3.pg,p3.pt);
            }
            else if(p1.pt!=p2.pt && p1.pt>p2.pt)
            {
                p3.pt=p1.pt*p2.pt;
                p2.pg=(p3.pt/p2.pt)*p2.pg;
                p3.pg=p1.pg-p2.pg;
                printf("%i/%i - %i/%i =%i/%i",p1.pg,p1.pt,p2.pg,p2.pt,p3.pg,p3.pt);
            }
            else
            {
                p3.pg=p1.pg-p2.pg;
                p3.pt=p1.pt;
                printf("%i/%i - %i/%i =%i/%i",p1.pg,p1.pt,p2.pg,p2.pt,p3.pg,p3.pt);

            }
        }break;
     case 3:
        {
                p3.pt=p1.pt*p2.pt;
                p3.pg=p1.pg*p2.pg;
                printf("%i/%i * %i/%i =%i/%i",p1.pg,p1.pt,p2.pg,p2.pt,p3.pg,p3.pt);


        }break;
        p3.k=0;
      case 4:
        {
            printf("\n%i/%i",p1.pg,p1.pt );
            printf(" : %i/%i =",p2.pg,p2.pt );
           p3.k =p2.pg;
           p2.pg=p2.pt;
           p2.pt=p3.k;
                p3.pt=p1.pt*p2.pt;
                p3.pg=p1.pg*p2.pg;
                printf("%i/%i * %i/%i =%i/%i",p1.pg,p1.pt,p2.pg,p2.pt,p3.pg,p3.pt);


        }break;
    }
    printf("\n\ningin mengulang ? ");
    fflush(stdin);
    scanf("%c",&ulang);

    }while(ulang=='y'||ulang=='Y');


}

