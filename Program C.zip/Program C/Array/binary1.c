#include <stdio.h>
#include <stdlib.h>

void main()
{
    int A[100],B[100],a,b,n,x,i,z;
    char ulang;

    srand(time(NULL));

    do
    {
    printf ("masukkan nilai n = ");
    scanf  ("%i",&n);
    z=0;
    for (i=0;i<n;i++)
    {
        A[i]=rand()/10000;
    }
    printf("Array A==");
    for (i=0;i<n;i++)
    {
        printf(" %i ",A[i]);
    }

    printf ("\nmasukkan nilai  = ");
    scanf  ("%i",&x);
    i=0;
    while(i<n&&A[i]!=x)
    {
        i++;
    }
    if(A[i]==x)
    {
       for(i=0;i<n;i++)
       {
           if(x==A[i])
           {
               printf("\nBilangan ada indeks ke %i",i);
           }
       }
    }
    else
    {
        printf("\ntidak ada");
    }

    printf("\napakah ulang == ");
    fflush(stdin);
    scanf("%c",&ulang);

    }while(ulang=='Y' || ulang=='y');
}
