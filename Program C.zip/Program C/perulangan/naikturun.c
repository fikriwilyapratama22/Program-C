#include "stdio.h"
void main()
{
    int i,na,nk;

    printf("masukkan nilai awal=");
    scanf("%i", &na);
    printf("masukkan nilai akhir=");
    scanf("%i", &nk);

    if (na<nk)
    {
        printf("nilai naik");
        for(i=na;i<=nk;i++)
        {
            printf(" %i", i);
        }
    }
    else
    {

        printf("nilai turun");
        for (i=na;i>=nk;i--)
        {
            printf(" %i", i);
        }
    }
    }



