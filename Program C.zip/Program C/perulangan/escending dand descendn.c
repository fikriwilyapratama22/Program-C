#include "stdio.h"
void main()
{
    int na,nk,i;

    printf("masukkan na=");
    scanf("%i", &na);
    printf("masukkan nk=");
    scanf("%i", &nk);

    for(i=na;i<=nk;i++)
    {
        if (i%3==0 && i%2==0)
        {
            printf(" %i", i);
        }
    }
}
