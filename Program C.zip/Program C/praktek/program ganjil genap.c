#include "stdio.h"
void main()
{
    int bilangan;

    printf("masukkan bilangan =");
    scanf("%i", &bilangan);

    if (bilangan % 2==0)
    {
        printf("%i adalah bilangan genap", bilangan);
    }
    else
    {
        printf("%i adalah bilangan ganjil",bilangan);
    }
}
