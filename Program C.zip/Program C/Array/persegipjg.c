/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: persegi panjang
**/

#include "stdio.h"

void main()
{
    int p,l,kll,luas,pilihan;

    printf("panjang==");
    scanf("%i",&p);
    printf("lebar==");
    scanf("%i",&l);

    printf("\nmenu persegi panjang:");
    printf("\n1.luas persegi panjang");
    printf("\n2.kll persegi panjang");
    printf("\npilih menu==");
    scanf("%i",&pilihan);

    if (pilihan==1)
    {
        luas=p*l;
        printf("\n luas persegi panjang=%i",luas);

    }
    else
    {
        (kll=2*(p+l));
        printf("\n keliling persegi panjang=%i",kll);
    }






}

