#include "stdio.h"
void main()
{
    typedef struct
    {
        int x,y,a;

    }titik;

    titik A,B;
    printf("Absis =");
    scanf("%i",&A.x);
     printf("ordinat =");
    scanf("%i",&A.y);
    printf("titik yang dimasukkan adalah = %i,%i", A.x,A.y);

    printf("\npencerminan terhadap sumbu x = %i,%i",A.x,-A.y);
     printf("\npencerminan terhadap sumbu x = %i,%i",-A.x,A.y);






}
