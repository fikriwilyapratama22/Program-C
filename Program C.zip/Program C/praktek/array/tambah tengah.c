#include "stdio.h"
#include "stdlib.h"
void main()
{
    int A[100],B[100],i,j,n,x;
    char u;
    srand(time(NULL));
    do{
        printf("masukkan ukuran array=");
        scanf("%i",&n);
       for(i=0;i<n;i++)
       {
           A[i]=rand()/1000;
       }
       printf("\narray A =");
       for(i=0;i<n;i++)
       {
           printf(" %i", A[i]);
       }
       printf("\nmasukkan nilai x =");
       scanf("%i",&x);
        j=0;
        for(i=0;i<=n;i++)
       {
           if(A[i]%2==3)
           {

               B[j+1]=A[i];
               B[3]=x;
           }
           else if(letak==1)
           {
             B[j]=A[i];
             A[n]=x;
               A[i]=B[i];
           }
       }
       printf("\narray B =");
       for(i=0;i<j;i++)
       {
           printf(" %i",A[i]);
       }
    printf("\napakah ulang =");
    fflush(stdin);
    scanf("%c",&u);
    }while(u=='y'||u=='Y');
}






