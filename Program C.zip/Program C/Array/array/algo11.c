#include <stdio.h>

void main()
{
    int a[10],b[10],c[10];
    int i,n,j,d;
    printf ("masukkan batas array = ");
    scanf ("%i",&n);

    for (i=0;i<n;i++)
    {
        printf ("masukan nilai array indeks ke %i = ",i);
        scanf  ("%i",&a[i]);
    }
    printf ("\n isi array a : ");
    for (i=0;i<n;i++)
    {
        printf (" %i ",a[i]);
    }

    d=a[0];
    for (i=0;i<n;i++)
    {

        b[i]= a[i+1];
        b[n-1]=d;

    }
    printf ("\n isi array a sekarang : ");
    for (i=0;i<n;i++)
    {

        printf (" %i ", b[i]);
    }

}
