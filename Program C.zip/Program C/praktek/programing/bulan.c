#include "stdio.h"
void main()
{
    int bulan;

    printf("bulan =");
    scanf("%i", &bulan);

    switch (bulan)
    {
    case 1 :
        {
            printf("januari");
        }break;
    case 2 :
        {
            printf("februari");
        }break;
    case 3 :
        {
            printf("maret");
        }break;
    case 4 :
        {
            printf("april");
        }break;
    case 5 :
        {
            printf("mei");
        }break;
    case 6 :
        {
            printf("juni");
        }break;
    case 7 :
        {
            printf("juli");
        }break;
    case 8 :
        {
            printf("agustus");
        }break;
    case 9 :
        {
            printf("september");
        }break;
    case 10 :
        {
            printf("oktober");
        }break;
    case 11 :
        {
            printf("november");
        }break;
    case 12 :
        {
            printf("desember");
        }break;
    default :
        printf("pilih menu salah");
    }
}

