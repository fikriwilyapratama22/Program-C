/** Nama        : Basmida Laia
    No BP       : 2201091003
    Deskripsi   : Logika matematika 2

*/
#include "stdio.h"
void main()
{
    int a,b;
    int kali,tambah,kurang,div,mod;
    float bagi;

    a=29;
    b=9;
    kali=a*b;
    bagi=(float)a/b;
    tambah=a+b;
    kurang=a-b;
    div=a/b;
    mod=a%b;

    printf("\nhasil kali = %i", kali);
    printf("\nhasil bagi = %f", bagi);
    printf("\nhasil tambah = %i", tambah);
    printf("\nhasil kurang = %i", kurang);
    printf("\nhasil div = %i", div);
    printf("\nhasil mod = %i", mod);

}
