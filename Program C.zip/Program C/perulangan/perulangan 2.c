#include "stdio.h"
void main()
{
    int i,na,nk,total,jumlah,maks,min;
    float rata;

    printf("masukkan nilai awal=");
    scanf("%i", &na);
    printf("masukkan nilai akhir =");
    scanf("%i", &nk);

    total=0;
    jumlah=0;
    maks=-900;
    min=900;


    for (i=na;i<=nk;i++)
    {
        if (i%3==0 && i%2==1 && i!=0)
        {
            printf(" %i", i);
            total=total+i;
            jumlah=jumlah+1;
        }
        if (i>maks)
        {
            maks=i;
        }
        if (i<min)
        {
            min=i;
        }
    }
    printf("\ntotal bilangan=%i", total);
    printf("\njumlah bilangan=%i", jumlah);
    printf("\nnilai maksimum =%i", maks);
    printf("\nnilai minimum =%i", min);
    rata=total/jumlah;
    printf("\nrata-rata =%.2f", rata);

}
