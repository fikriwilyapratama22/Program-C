#include "stdio.h"
void main()
{
    int i,j,hasil;

    for (i=1;i<=3;i++)
    {
        for (j=1;j<=4;j++)
        {
            printf("%i", i);
        }
        printf("\n");

    }

}
