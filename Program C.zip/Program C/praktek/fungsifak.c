#include "stdio.h"

long int faktorial(int x)
{
    long int fak;
    int i;
    fak = 1;

    for(i=1;i<=x;i++)
    {
        fak = fak *i;
    }

    return(fak);
}

long  int perm(int x,int y)
{
    long int permutasi;
    permutasi = faktorial(x)/(faktorial(x-y));
    return permutasi;
}

long int komb(int x,int y)
{
    long int kombinasi;
    kombinasi = faktorial(x)/(faktorial(x-y)*faktorial(y));
    return(kombinasi);
}

int main()
{
    int n,m,z;

    printf("input nilai faktorial yang dicari =");
    scanf("%i",&n);
    printf("input nilai faktorial yang dicari =");
    scanf("%i",&m);
    printf("input nilai faktorial yang dicari =");
    scanf("%i",&z);


    printf("\nfaktorial dari %i =%li",n,faktorial(n));
    printf("\nfaktorial dari %i =%li",m,faktorial(m));
    printf("\nfaktorial dari %i =%li",z,faktorial(z));

    printf("\n %i P %i =%li",n,m,perm(n,m));

    printf("\nhasil kombinasi = %li",komb(n,m));

    return 0;

}


