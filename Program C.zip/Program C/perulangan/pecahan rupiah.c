/** konversikan uang dolar kedalam rupiah(1 dolar = 14.000)
    lalu konversikan uang tersebut ke pecahan 100ribu,pecahan 50ribu,pecahan 20ribu,pecahan 10 ribu
    pecahan 5ribu,pecahan 2ribu,pecahan 1ribu,pecahan 500 rupiah.
**/
#include "stdio.h"
void main()
{
    long int dolar,rupiah,pecahan100,sisa100,pecahan50,sisa50,pecahan20,sisa20,pecahan10,sisa10,pecahan5,sisa5,
             pecahan2,sisa2,pecahan1,sisa1,pecahan500;

    printf("masukkan jumlah uang dolar =");
    scanf("%li", &dolar);

    rupiah      =   dolar*14000;
    pecahan100  =   rupiah/100000;
    sisa100     =   rupiah%100000;
    pecahan50   =   sisa100/50000;
    sisa50      =   sisa100%50000;
    pecahan20   =   sisa50/20000;
    sisa20      =   sisa50%20000;
    pecahan10   =   sisa20/10000;
    sisa10      =   sisa20%10000;
    pecahan5    =   sisa10/5000;
    sisa5       =   sisa10%5000;
    pecahan2    =   sisa5/2000;
    sisa2       =   sisa5%2000;
    pecahan1    =   sisa2/1000;
    sisa1       =   sisa2%1000;
    pecahan500  =   sisa1/500;

    printf("\ntotal rupiah\t\t=%li", rupiah);
    printf("\njumlah pecahan 100 ribu\t=%li", pecahan100);
    printf("\njumlah pecahan 50 ribu\t=%li",pecahan50);
    printf("\njumlah pecahan 20 ribu\t=%li", pecahan20);
    printf("\njumlah pecahan 10 ribu\t=%li", pecahan10);
    printf("\njumlah pecahan 5 ribu\t=%li", pecahan5);
    printf("\njumlah pecahan 2 ribu\t=%li", pecahan2);
    printf("\njumlah pecahan 1 ribu\t=%li", pecahan1);
    printf("\njumlah pecahan 500\t=%li", pecahan500);

}
