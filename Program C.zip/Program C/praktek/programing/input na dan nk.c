/** Nama        : Basmida Laia
    NIM         : 2201091003
    Deskripsi   : perulangan for
**/
#include "stdio.h"
void main()
{
    int i,na,nk;

    printf("masukkan nilai awal =");
    scanf("%i", &na);
    printf("masukkan nilai akhir =");
    scanf("%i", &nk);

    for (i=na;i<=nk;i++)
    {
        printf(" %i", i);
    }
}
