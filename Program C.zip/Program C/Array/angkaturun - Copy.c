/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: perulangan angka 2
**/

#include "stdio.h"

void main()
{
    int i,na,nk;



    printf("masukkan nilai awal==");
    scanf("%i",&na);
    printf("masukkan nilai akhir==");
    scanf("%i",&nk);


    if(na<nk)
    {

        printf("\nnilai naik");
        for(i=na; i<=nk; i++)
        {
             printf(" %i",i);
        }

    }
    else
    {


        printf("\nnilai turun");
        for(i=na; i>=nk; i--)
        {
            printf(" %i",i);
        }


    }

}
