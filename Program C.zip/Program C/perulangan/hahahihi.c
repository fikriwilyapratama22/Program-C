/** Tulis program untuk menentukan lama bekerja seorang pegawai,
    jika jammasuk dan jam pulang diinput.
    Catatan: jam berupa angka 1-12, danseorang pegawai bekerja kurang dari 12 jam
**/

#include "stdio.h"
void main()
{
    int jm,jk,lama;

    printf("jam masuk =");
    scanf("%i", &jm);
    printf("jam keluar =");
    scanf("%i", &jk);


}
