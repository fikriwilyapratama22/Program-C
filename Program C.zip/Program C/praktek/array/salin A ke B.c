#include "stdio.h"
void main()
{
    int A[100],B[100];
    char ulang;
    int i,j,n;

    do{
        printf("masukkan ukuran array =");
        scanf("%i",&n);
        for(i=0;i<n-1;i++)
        {
            scanf("%i",&A[i]);
        }
        printf("\narray A =");
         for(i=0;i<n-1;i++)
        {
            printf(" %i",A[i]);

        }
         for(i=0;i<n-1;i++)
        {
           B[i]=A[i];
        }
        printf("\narray B =");
         for(i=0;i<n-1;i++)
        {
            printf(" %i",B[i]);

        }


        printf("\napakah ulang =");
        fflush(stdin);
        scanf("%c",&ulang);
    }while(ulang=='y'||ulang=='Y');
}
