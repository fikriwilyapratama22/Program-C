#include "stdio.h"
#include "stdlib.h"
void main()

{

    int A[100][100],B[100][100],C[100][100];
    int i,j,ba,ka,bb,kb,menu;
    char ulang;
     do{
     srand(time(NULL));

    printf("pilih menu =");
    scanf("%i",&menu);

    switch(menu)
    {
    case 1 :
        {
            printf("masukkan jumlah baris a =");
            scanf("%i",&ba);
            printf("masukkan jumlah kolom a =");
            scanf("%i",&ka);
            printf("masukkan jumlah baris b =");
            scanf("%i",&bb);
            printf("masukkan jumlah baris b =");
            scanf("%i",&kb);

            if(ba==bb && ka==kb)
            {
                 printf("\nmatriks A =\n");
                for(i=0;i<ba;i++)
                {
                    for(j=0;j<ka;j++)
                    {
                        printf("input nilai array A indeks [%i][%i]=",i,j);
                        scanf("%i",&A[i][j]);

                    }
                }
                 printf("\ntampilan A =\n");
                    for(i=0;i<ba;i++)
                    {
                        for(j=0;j<ka;j++)
                        {
                            printf(" %i",A[i][j]);
                        }
                        printf("\n");
                    }

                   printf("\nmatriks B =\n");
                    for(i=0;i<bb;i++)
                    {
                        for(j=0;j<kb;j++)
                        {
                            B[i][j]=rand()/10000;
                        }

                    }
                                    printf("\ntampilan B =\n");
                    for(i=0;i<bb;i++)
                    {
                        for(j=0;j<kb;j++)
                        {
                            printf(" %i",B[i][j]);
                        }
                        printf("\n");
                    }
                     for(i=0;i<ba+bb;i++)
                    {
                        for(j=0;j<ka+kb;j++)
                        {
                           C[i][j]= A[i][j]+B[i][j];
                        }

                    }
                    printf("\ntampilan C =\n");
                    for(i=0;i<bb;i++)
                    {
                        for(j=0;j<kb;j++)
                        {
                            printf(" %i",C[i][j]);
                        }
                        printf("\n");
                    }
            }
            else
            {
                printf("ukuran tidak sama");
            }
            printf("\n");
        }break;
            case 2 :
        {
            printf("masukkan jumlah baris a =");
            scanf("%i",&ba);
            printf("masukkan jumlah kolom a =");
            scanf("%i",&ka);
            printf("masukkan jumlah baris b =");
            scanf("%i",&bb);
            printf("masukkan jumlah baris b =");
            scanf("%i",&kb);

            if(ba==bb && ka==kb)
            {
                 printf("\nmatriks A =\n");
                for(i=0;i<ba;i++)
                {
                    for(j=0;j<ka;j++)
                    {
                        printf("input nilai array A indeks [%i][%i]=",i,j);
                        scanf("%i",&A[i][j]);

                    }
                }
                 printf("\ntampilan A =\n");
                    for(i=0;i<ba;i++)
                    {
                        for(j=0;j<ka;j++)
                        {
                            printf(" %i",A[i][j]);
                        }
                        printf("\n");
                    }

                   printf("\nmatriks B =\n");
                    for(i=0;i<bb;i++)
                    {
                        for(j=0;j<kb;j++)
                        {
                            B[i][j]=rand()/10000;
                        }

                    }
                                    printf("\ntampilan B =\n");
                    for(i=0;i<bb;i++)
                    {
                        for(j=0;j<kb;j++)
                        {
                            printf(" %i",B[i][j]);
                        }
                        printf("\n");
                    }
                     for(i=0;i<ba+bb;i++)
                    {
                        for(j=0;j<ka+kb;j++)
                        {
                           C[i][j]= A[i][j]-B[i][j];
                        }

                    }
                    printf("\ntampilan C =\n");
                    for(i=0;i<bb;i++)
                    {
                        for(j=0;j<kb;j++)
                        {
                            printf(" %i",C[i][j]);
                        }
                        printf("\n");
                    }
            }
            else
            {
                printf("ukuran tidak sama");
            }
            printf("\n");
        }break;
            default :
                printf("manu salah");

    }






    printf("apakah ulang =");
    fflush(stdin);
    scanf("%c",&ulang);

    }while(ulang=='y'||ulang=='Y');
}

