#include <stdio.h>
#include <stdlib.h>

main(){

    int b,n;
    int i,x;
    char ulang;
    int t,C;
    srand(time(NULL));

    printf("INPUT UKURAN : ");scanf("%d",&n);
      int *a = malloc(sizeof(int));
      int *b = malloc(sizeof(int));
      t = 0;


     for (i=0;i<n;i++)
         {
         a[i]=rand()/1000;
         }
    printf("\n");
    printf("NILAI ARRAY \n");


     for (i =0;i<n;i++
        {
        printf(" %d",a[i]);
        }
    printf("\nINPUT SEBUAH NILAI : ");
    scanf("%d",&x);
    printf("INPUT LOKASI LETAK NILAI : ");
    scanf("%d",&C);

     for (i =0;i<=n; i++)
        {
        if(C == 0)
        {
            b[0] = x;
            b[i+1] = a[i];
        }
         else if(C ==1)
         {
            b[1] = x;
            b[0]= a[0];
            b[i+1] = a[i];
        }
         else if(C ==2){
            b[2] = x;
            b[0]= a[0];
            b[1]=a[1];
            b[i+1] = a[i];
        }
       else if(C ==3){
            b[3] = x;
            b[0]= a[0];
            b[1]=a[1];
            b[2]=a[2];
            b[i+1] = a[i];
        }else if(C ==4){
            b[4] = x;
            b[0]= a[0];
            b[1]=a[1];
            b[2]=a[2];
            b[3]=a[3];
            b[i+1] = a[i];
        }
        b[C] = x;
        b[i+C+1] = a[i];

    }
    for (i = 0;i <= n; i++){
        printf("\t%d",b[i]);
    }

    int y;

   // printf("\nMasukkan bilangan yang akan anda cari : ");scanf("%d",&y);

    //mencari nilai berada pada indeks ke
  /**  for (i = 0; i <= n; i++){
        if (y == d[i]){
            printf("\nBilangan yang anda cari terletak pada indeks ke = %d",i);
        }
    }**/
    //menjumlahkan nilai dalam array
    for (i = 0;i <= n; i++){
       t = t + d[i];
        }
    printf("\n===================================================");
    printf("\n\nHASIL PENJUMLAHAN ARRAY = %d",t);

   /** printf("apakah ulang =");
    fflush(stdin);
    scanf("%c",&ulang);

    }while(ulang=='y'||ulang=='Y');
**/
}
