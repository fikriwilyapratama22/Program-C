#include <stdio.h>
#include <stdlib.h>

void main()
{
    int i,n,x,ia,ik,it,ketemu,idx;
    int A[10];
    printf ("masukkan nilai n = ");
    scanf  ("%i",&n);
    for (i=0;i<=n-1;i++)
    {
        printf ("masukan nilai array indeks ke %i = ",i);
        scanf  ("%i",&A[i]);
    }
    for (i=0;i<=n-1;i++)
    {
        printf ("  %i ",A[i]);
    }
    printf ("\nmasukkan nilai yang dicari = ");
    scanf  ("%i",&x);
    ia = 0;
    ik = n-1;
    ketemu = 0;
    for(i=0;i<=n-1;i++)
    {
        it = (ia+ik)/2;
        if (A[it] = x)
         {ketemu = 1;
         idx = it;}
        if (A[it]>x)
         {ik = it - 1;}
        else
         {ia = it + 1;}

    }
    if (ketemu==1)
    {printf ("ada pada i");}
    else
    {printf ("tidak ada");}

    free((void*)A);
}
