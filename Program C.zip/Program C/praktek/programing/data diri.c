#include "stdio.h"

void main()

{

 printf("nama    : basmida laia \n");
 printf("jurusan : teknologi informasi \n");
 printf("prodi   : d-3 manajemen informatika \n");
 printf("kelas   : 1 mib \n");
 printf("no bp   : 2201091003 \n");
 printf("motto   : keajaiban adalah kata lain dari kerja keras \n");




}
