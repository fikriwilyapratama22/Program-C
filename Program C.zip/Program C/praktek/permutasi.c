 #include "stdio.h"
void main()
{
    int i,a,b,c;
    long int fa,fb,permutasi;

    printf("masukkan nilai a=");
    scanf("%i", &a);
    printf("masukkan nilai b=");
    scanf("%i", &b);

    fa=1;
    fb=1;
    c=a-b;
    for (i=1;i<=a;i++)
    {
        fa=fa*i;
    }
    printf("\n%i vaktorial =%li", a,fa);
    for (i=1;i<=c;i++)
    {
        fb=fb*i;
    }
    printf("\n%i vaktorial =%li", b,fb);
        permutasi=fa/fb;
        printf("\npermutasi=%li", permutasi);
}
