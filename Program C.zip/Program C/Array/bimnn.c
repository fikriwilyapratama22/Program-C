#include <stdio.h>


void main()
{
    int A[100],z,ia,ik,it,n,x,i;
    char ulang;

    do
    {
    #include <stdio.h>


void main()
{
    int A[100],z,ia,ik,it,n,x,i;
    char ulang;

    do
    {
    printf ("masukkan nilai n = ");
    scanf  ("%i",&n);
    for(i=0;i<n;i++)
    {
        scanf("%i",&A[i]);
    }
    printf("\nNilai Array==\n");
     for(i=0;i<n;i++)
    {
        printf("%i",A[i]);
    }
    printf("\nmasukkan x=");
    scanf(" %i ",&x);
    z=0;
    ia=0;
    ik=n-1;
    for(i=0;i<n-1;i++)
    {
    it=(ia+ik)/2;

    if(A[it]==x)
    {
        z=1;
    }
    else if(A[it]<x)
    {
        ik=it-1;
    }
    else if(A[it]>x)
    {
        ia=it+1;
    }
    }
    if(z==1)
    {
        printf("\nada");

    }
    else
    {
        printf("\ntdk ada");
    }

     printf("\napakah ulang == ");
    fflush(stdin);
    scanf("%c",&ulang);

    }while(ulang=='Y' || ulang=='y');
}

    z=0;
    ia=0;
    ik=n-1;
    for(i=0;i<n-1;i++)
    {
            it =( ia+ ik)/2;

            if(A[it]==x)
            {
                z=1;
            }
            else if(A[it]<x)
            {
                ik=it-1;
            }
            else if(A[it]>x)
            {
                ia=it+1;
            }
    }
    if(z==1)
    {
        printf("\nada");

    }
    else
    {
        printf("\ntdk ada");
    }

     printf("\napakah ulang == ");
    fflush(stdin);
    scanf("%c",&ulang);

    }while(ulang=='Y' || ulang=='y');
}
