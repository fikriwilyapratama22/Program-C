#include "stdio.h"

void main()
{
    int i,k,j,m,n,o;

    printf("Masukan Baris =");
    scanf("%i",&o);

    for(i=1 ;i<=o ;i++)
    {
        for(k=1 ;k<=i ;k++)
        {
            printf("*");
        }
        for(j=o ;j>=i ;j--)
        {
            printf("0");
        }
        for(m=o ;m>=i ;m--)
        {
            printf("0");
        }
        for(n=1 ;n<=i ;n++)
        {
            printf("*");
        }
        printf("\n");
    }
}
