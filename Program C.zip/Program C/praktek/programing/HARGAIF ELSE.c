/** Nama        : Basmida Laia
    NIM         : 2201091003
    Deskripsi   : Harga Beli
*/

#include "stdio.h"
void main()
{
    long int pena,pensil,buku,spidol,hargapena,hargapensil,hargabuku,hargaspidol;
    long int dispena,disbuku,dispena_buku,tsdiskon,totalbayar,pajak;


    printf("jumlah pena\t=");
    scanf("%li", &pena);
    printf("jumlah pensil\t=");
    scanf("%li", &pensil);
    printf("jumlah buku\t=");
    scanf("%li", &buku);
    printf("jumlah spidol\t=");
    scanf("%li", &spidol);

    hargapena=pena*3500;
    hargapensil=pensil*4000;
    hargabuku=buku*5500;
    hargaspidol=spidol*6500;

    printf("\nharga pena\t=%li", hargapena);
    printf("\nharga pensil\t=%li", hargapensil);
    printf("\nharga buku\t=%li", hargabuku);
    printf("\nharga spidol\t=%li", hargaspidol);

    if (pena>5)
    {
        dispena=(5*hargapena)/100;
        printf("\ndiskon pena\t=%li", dispena);
    }
    else
    {
        dispena=0*hargapena;
        printf("\ndiskon pena\t=%li", dispena);
    }
    if (buku>10)
    {
        disbuku=(10*hargabuku)/100;
        printf("\ndiskon buku\t=%li", disbuku);
    }
    else
    {
        disbuku=0*hargabuku;
        printf("\ndiskon buku\t=%li", disbuku);
    }

    dispena_buku = dispena+disbuku;
    printf("\ntotal diskon pena dan buku\t= %li", dispena_buku);

    tsdiskon=(hargapena-dispena)+(hargabuku-disbuku)+hargapensil+hargaspidol;
    printf("\ntotal setelah diskon\t\t=%li", tsdiskon);

    pajak=(10*tsdiskon)/100;
    printf("\ntotal pajak\t\t\t=%li", pajak);

    totalbayar = tsdiskon+pajak;
    printf("\ntotal bayar setelah pajak\t=%li", totalbayar);

}
