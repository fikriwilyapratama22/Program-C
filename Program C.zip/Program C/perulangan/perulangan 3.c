/** buat program yang menampilkan deret dimana nilai awal dan akhir input user
    bilangan yang kelipatan 7 dan bernilai ganjil,hitung jumlah nilainya dan berapa
    banyak bilangan pada deret tersebut,serta tentukan nilai maksimum dan minimum
    juga rata-ratanya.
**/
#include "stdio.h"
void main()
{
     int i,na,nk,jumlah,total,maks,min;
     float rata;

     printf("masukkan nilai awal=");
     scanf("%i", &na);
     printf("masukkan nilai akhir=");
     scanf("%i", &nk);

     jumlah=0;
     total=0;
     maks=-900;
     min=900;

     for (i=na;i<=nk;i++)
     {
         if (i%7==0 && i%2==1)
         {
             printf(" %i", i);
             total=total+i;
             jumlah=jumlah+1;
         }
         if (i>maks)
         {
             maks=i;
         }
         if (i<min)
         {
             min=i;
         }
     }
     printf("\ntotal\t\t=%i", total);
     printf("\njumlah\t\t=%i", jumlah);
     printf("\nnilai maksimum\t=%i", maks);
     printf("\nnilai minimum\t=%i", min);
     rata=total/jumlah;
     printf("\nrata-rata\t=%.1f", rata);
}
