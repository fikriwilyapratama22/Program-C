/** Nama        : Linus dimbau
    NIM         : 2201091008
    Deskripsi   : pola 1

    $ $ $ $ $ $
    $         $
    $         $
    $ $ $ $ $ $
*/
#include "stdio.h"
void main ()
{
    int i,j,b,k;

    printf("Masukkan jumlah baris =");
    scanf("%i", &b);
    printf("Masukkan jumlah kolom =");
    scanf("%i", &k);

    for (i=1;i<=b;i++)
    {
        for (j=1;j<=k;j++)
        {
             if (i==1 ||i==8  || j==1 || j==8)
            {
                printf(" $ ");
            }
            else
            {
                printf("    ");
            }
        }
         printf("\n");
    }

}
