/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: uts
**/

#include "stdio.h"

void main()
{

}
