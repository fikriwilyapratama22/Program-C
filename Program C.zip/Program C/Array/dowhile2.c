/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: do while 1
**/

#include "stdio.h"

void main()
{




    int i,j,k,n,menu,m,a,b,c,s;
    int ulang;

    do
    {


    printf("masukkan n bung=");
    scanf("%i",&n);
    printf("pilih menu bung!");
    scanf("%i",&menu);



   switch(menu)
   {
   case 1 :
    {
         for(i=1;i<=n;i++)
    {
        for(j=n;j>=i;j--)
        {
            printf("   ");

        }
        for(m=1;m<=i;m++)
        {
            printf(" * ");

        }
        printf("\n");
    }
    }break;
   case 2 :
    {
         for(i=n;i>=1;i--)
    {


        for(j=n;j>=i;j--)
        {
            printf(" * ");
        }
        printf("\n");


    }
    }break;
   case 3 :
    {
     for(i=1;i<=n;i++)
    {


        for(j=1;j<=n;j++)
        {
        if (i==1 || i==n|| j==1 || j==n)
        {
                printf(" * ");
        }
        else
        {
            printf("   ");
        }

        }
        printf(" \n ");


    }

    }break;
   case 4 :
    {
        for(i=1;i<=n;i++)
        {


            for(j=1;j<=n;j++)
            {
                if (i==2 && j==3 || i==3 && j==2)
            {
                printf("   ");
            }
                else
            {
                printf(" * ");
            }

            }
        printf(" \n ");


        }
    }break;



   }
   printf("\nulang kah kidz=");
   scanf("%i",&ulang);
    }while(ulang==1 || ulang==0);
}
