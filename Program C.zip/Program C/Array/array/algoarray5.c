#include <stdio.h>

void main()
{
    int a[10];
    char huruf;
    huruf = 'a';
    e=1;
    printf ("masukkan batas array = ");
    scanf ("%i",&n);
    for (i=0;i<n;i++)
    {
        if(i%2==0)
        {
            f[i]=e;
            printf (" %i ",a[i]== a);

        }
        else
        {
            printf (" %i ",a[i]);
        }

    }
}
