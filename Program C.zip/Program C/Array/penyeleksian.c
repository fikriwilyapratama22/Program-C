/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: kabisat
**/

#include "stdio.h"

void main()
{
    int tahun,jumlahhari,nilai;

    printf("pilih nilai==");
    scanf("%i",&nilai);
    printf("pilih tahun==");
    scanf("%i",&tahun);

    switch (nilai)
    {
    case 1 :
        {
            printf("januari ");
            jumlahhari=31;
            printf("jumlah hari bulan januari pada tahun %i = %i",tahun,jumlahhari);

        }break;
    case 2 :
        {
            printf("februari");
            if(tahun % 4 == 0)
            {
                printf("\nmerupakan tahun kabisat");
                jumlahhari= 29;
                printf("\njumlah hari bulan februari pada tahun %i = %i",tahun,jumlahhari);
            }
            else
            {
                printf("\nbukan kabisat");
                jumlahhari=28;
                printf("\njumlah hari bulan februari pada tahun %i = %i",tahun,jumlahhari);

            }
        }break;
        case 3 :
        {
            printf("maret ");
            jumlahhari=31;
            printf("\n jumlah hari bulan maret pada tahun %i = %i",tahun,jumlahhari);

        }break;
        case 4 :
        {
            printf("april");
            jumlahhari=30;
            printf("\n jumlah hari bulan april pada tahun %i = %i",tahun,jumlahhari);

        }break;
        case 5 :
        {
            printf("mei ");
            jumlahhari=31;
            printf("\n jumlah hari bulan mei pada tahun %i = %i",tahun,jumlahhari);

        }break;
        case 6 :
        {
            printf("juni ");
            jumlahhari=30;
            printf("\njumlah hari bulan juni pada tahun %i = %i",tahun,jumlahhari);

        }break;
        case 7 :
        {
            printf("juli ");
            jumlahhari=31;
            printf("\njumlah hari bulan juli pada tahun %i = %i",tahun,jumlahhari);

        }break;
        case 8 :
        {
            printf("agustus ");
            jumlahhari=31;
            printf("\njumlah hari bulan agustus pada tahun %i = %i",tahun,jumlahhari);

        }break;
        case 9 :
        {
            printf("september ");
            jumlahhari=30;
            printf("\njumlah hari bulan september pada tahun %i = %i",tahun,jumlahhari);

        }break;
        case 10 :
        {
            printf("oktober ");
            jumlahhari=31;
            printf("\njumlah hari bulan oktober pada tahun %i = %i",tahun,jumlahhari);

        }break;
        case 11 :
        {
            printf("november ");
            jumlahhari=30;
            printf("\njumlah hari bulan november pada tahun %i = %i",tahun,jumlahhari);

        }break;
        case 12 :
        {
            printf("desember ");
            jumlahhari=31;
            printf("\njumlah hari bulan desember pada tahun %i = %i",tahun,jumlahhari);

        }break;
        default: printf("plihan salah");
    }
}
