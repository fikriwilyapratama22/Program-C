#include "stdio.h"

 long int maks(int a, int b);
 long int min(int a, int b);

 void main()
 {
     int n1,n2,n3,n4;
     long int L;
     printf("masukkan nilai 1= ");
     scanf("%i",&n1);
     printf("masukkan nilai 2= ");
     scanf("%i",&n2);
     printf("masukkan nilai 2= ");
     scanf("%i",&n3);
      printf("masukkan nilai 2= ");
     scanf("%i",&n4);

     printf("nilai maksimum= %li",maks(maks( maks(n1,n2),n3),n4));
    printf("\nminimum dari %i dan %i = %li",n1,n2, min(n1,n2) );


 }
long int maks(int a, int b)
{
    if (a>b)
    {
        return (a);
    }
    else
    {
        return (b);
    }
}
long int min(int a, int b)
{
    if (a<b)
    {
        return (a);
    }
    else
    {
        return (b);
    }
}

