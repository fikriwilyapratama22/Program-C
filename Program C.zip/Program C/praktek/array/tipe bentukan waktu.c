
#include "stdio.h"
void main()
{
    typedef struct
    {
        int j,m,d;

    }waktu ;
    waktu w1,w2,w3;


    printf("jam =");
    scanf("%i",&w1.j);
     printf("menit =");
    scanf("%i",&w1.m);
     printf("detik =");
    scanf("%i",&w1.d);

    printf("jam kedua =");
    scanf("%i",&w2.j);
     printf("menit kedua=");
    scanf("%i",&w2.m);
     printf("detik kedua =");
    scanf("%i",&w2.d);

    w3.j=w1.j-w2.j;
    w3.m=w1.m-w2.m;
    w3.d=w1.d-w2.d;


    printf("\nwaktu pertama =%i jam, %i menit, %i detik",w1.j,w1.m,w1.d);
    printf("\nwaktu kedua =%i jam, %i menit, %i detik",w2.j,w2.m,w2.d);
    printf("\nselisih w1 dan w2 =%i jam , %imenit,  %idetik",w3.j,w3.m,w3.d);








}
