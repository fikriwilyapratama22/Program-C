/** Nama: Fikri Wilya Pratama
    Nim: 2201091017
*/

#include "stdio.h"

void main()
{
    int celcius;
    int kelvin;
    float fahreinheit;
    float reamur;

    printf("celcius=");
    scanf("%i",&celcius);

    kelvin= 273 + celcius;
    fahreinheit=(float) 9/5 *celcius + 32;
    reamur=(float) 4/5 *celcius;

    printf("\n kelvin = %i",kelvin);
    printf("\n fareinheit = %0.2f",fahreinheit);
    printf("\n reamur = %0.2f",reamur);


}

