#include "stdio.h"
#include "stdlib.h"
void main()
{
    int A[100],B[100];
    int i,j;
    char u;

    srand(time(NULL));
    do{
        for(i=0;i<5;i++)
        {
            A[i]=rand()/1000;
        }
        printf("array A =");
         for(i=0;i<5;i++)
        {
            printf(" %i",A[i]);
        }
            j=5-1;
         for(i=0;i<5;i++)
        {
            B[i]=A[j];
            j=j-1;
        }
        printf("\narray B =");
         for(i=0;i<5;i++)
        {
            printf(" %i",B[i]);
        }



        printf("\napakah ulang =");
        fflush(stdin);
        scanf("%c",&u);
    }while(u=='y'||u=='Y');
}
