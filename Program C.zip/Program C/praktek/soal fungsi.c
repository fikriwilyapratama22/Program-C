#include "stdio.h"
#include "math.h"

long int nilai(int x, int y);

 void main()
 {
     int a,b;

     printf("masukkan nilai a= ");
     scanf("%i",&a);
     printf("masukkan nilai b= ");
     scanf("%i",&b);

     printf(" hasil = %li", nilai(a,b) );
 }
long int nilai(int x, int y)
{
    long int hasil;
    hasil=pow(x,3)+3*pow(x,2)*y+3*x*pow(y,2)+pow(y,3);
    return(hasil);
}
