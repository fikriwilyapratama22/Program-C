

#include "stdio.h"

void main()
{
    int a,b,c,j,i,k,n;
    i=1;
    while(n!=0)
    {

    printf("mahasiswa %i=",i+1);
    scanf("%i",&n);
    i++;


    }
}

