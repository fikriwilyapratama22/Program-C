/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: soal1
**/

#include "stdio.h"

void main()
{
    int gol,jamkerja,jamlembur,anak;
    long int totalgaji,gajipo,gajijam,pajak,setelahpajak,gajilembur,gajil;
    //float pajak,setelahpajak;

    printf("\nmasukkan golongan=");
    scanf("%i",&gol);
    printf("\nmasukkan jam kerja=");
    scanf("%i",&jamkerja);
    printf("\nmasukkan anak=");
    scanf("%i",&anak);




    switch(gol)
    {
    case 1:
    {
        if(jamkerja>10)
        {
        gajipo=50000;
        gajil=10000;
        gajijam=10*5000;
        gajilembur =((jamkerja-10)*10000);

        totalgaji=gajipo+gajilembur+gajilembur;
        pajak= 0.05 * totalgaji;
        setelahpajak=totalgaji-pajak;
        printf("gaji jam=%li",gajijam);
        printf("gaji setlembur=%li",gajilembur);
        printf("\npajak=%li",pajak);
        printf("\nsetelahpajak=%li",setelahpajak);
        if(anak<=3)
        {
            anak=35000*anak;
            gajianak=anak+setelahpajak;
            printf("total gaji tambah anak=%li",anak);
        }
        else
        {
            anak=3*35000;

        }
        }
        else
        {
        gajipo=50000;

        gajijam = 5000*jamkerja;

        totalgaji=gajipo+gajilembur;
        pajak= 0.05 * totalgaji;
        setelahpajak=totalgaji-pajak;
        printf("\npajak=%li",pajak);
        printf("\nsetelahpajak=%li",setelahpajak);
        }




    }break;
    case 2:
    {
        if(jamkerja>10)
        {
        gajipo=70000;

        gajilembur = (6000*10) + ((jamkerja-10)*15000);

        totalgaji=gajipo+gajilembur;
        pajak= 0.05 * totalgaji;
        setelahpajak=totalgaji-pajak;
        printf("\npajak=%li",pajak);
        printf("\nsetelahpajak=%li",setelahpajak);
        }
        else
        {
        gajipo=70000;

        gajijam = 6000*jamkerja;

        totalgaji=gajipo+gajilembur;
        pajak= 0.05 * totalgaji;
        setelahpajak=totalgaji-pajak;
        printf("\npajak=%li",pajak);
        printf("\nsetelahpajak=%li",setelahpajak);
        }


    }break;
    case 3:
    {
         if(jamkerja>10)
        {
        gajipo=100000;

        gajilembur = (7000*10) + ((jamkerja-10)*20000);

        totalgaji=gajipo+gajilembur;
        pajak= 0.1 * totalgaji;
        setelahpajak=totalgaji-pajak;
        printf("\npajak=%li",pajak);
        printf("\nsetelahpajak=%li",setelahpajak);
        }
        else
        {
        gajipo=100000;

        gajijam = 7000*jamkerja;

        totalgaji=gajipo+gajilembur;
        pajak= 0.1 * totalgaji;
        setelahpajak=totalgaji-pajak;
        printf("\npajak=%li",pajak);
        printf("\nsetelahpajak=%li",setelahpajak);
        }


    }break;
    default:
            printf("pilihan salah");

    }


}

