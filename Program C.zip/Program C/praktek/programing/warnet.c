/** Nama        : Ayunda Aulia Rahmi
    NIM         :
    Deskripsi   : jasa warnet
*/
#include "stdio.h"
void main()
{
    int waktu,pilmen,biaya;


    printf("\nMENU PELANGGAN");
    printf("\n1. Pelanggan VIP");
    printf("\n2. Pelanggan Tetap");
    printf("\n3. Pelanggan Biasa ");

    printf("\nSilahkan pilih menu : ");
    scanf("%i", &pilmen);
    printf("\nlama waktu =");
    scanf("%i", &waktu);

    switch (pilmen)
    {
        case 1 :
        {
            biaya=waktu*2000;
            printf("\nBIAYA = %i", biaya);
            }break;
        case 2 :
        {
            if (waktu<=3)
            {
                biaya=waktu*3000;
                printf("\nBIAYA =%i", biaya);
            }
            else
            {
                biaya=(3*3000)+(waktu-3)*2000;
                printf("\nBIAYA =%i", biaya);
            }
            }break;
        case 3 :
        {
             if (waktu<=3)
            {
                biaya=(waktu*3000)+5000;
                printf("\nBIAYA =%i", biaya);
            }
            else
            {
                biaya=(3*3000)+((waktu-3)*2000)+5000;
                printf("\nBIAYA =%i", biaya);
            }
            }break;
    default:
        printf("\nPilihan Menu Salah");
    }
}
