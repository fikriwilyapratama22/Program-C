/** Nama        : Basmida Laia
    NIM         : 2201091003
    Deskripsi   : Harga beli
*/
#include "stdio.h"
void main()
{
    long int pena,pensil,buku,spidol,hpena,hpensil,hbuku,hspidol;
    long int

    printf("\nmasukkan jumlah pembelian pena= ",pena);
    scanf("%li", &pena);
    printf("\nmasukkan jumlah pembelian pensil=");
    scanf("%li", &pensil);
    printf("\nmasukkan jumlah pembelian buku=");
    scanf("%li", &buku);
    printf("\nmasukkan jumlah pembelian spidol=");
    scanf("%li", &spidol);

    hpena=pena*3500;
    hpensil=pensil*4000;
    hbuku=buku*5500;
    hspidol=spidol*6500;

    printf("harga pena =%li", hpena);
    printf("harga pensil =%li", hpensil);
    printf("harga buku =%li", hbuku);
    printf("harga spidol =%li", hspidol);





}
