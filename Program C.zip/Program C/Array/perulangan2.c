/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: perulangan angka 2
**/

#include "stdio.h"

void main()
{
    int i;
    int na,nk;
    int total,jumlah,nmak,nmin;
    float rata;

    printf("masukkan nilai awal==");
    scanf("%i",&na);
    printf("masukkan nilai akhir==");
    scanf("%i",&nk);
    total=0;
    jumlah=0;
    nmak=-9999;
    nmin=9999;

    for(i=na; i<=nk; i==)
    {
        if((i % 7==0) && ( i %2==1))
        {


        printf(" %i",i);
        total= total+i;
        jumlah=jumlah+1;
         if(i>nmak)
            nmak=i;
        if(i<nmin)
            nmin=i;
        }

    }
    printf("\ntotal=%i",total);
    printf("\njumlah=%i",jumlah);
    rata=(float)total/jumlah;
    printf("\nrata-rata=%0.1f",rata);
    printf("\nnilai max=%i",nmak);
    printf("\nnilai min=%i",nmin);
}

