/** Nama        : Basmida Laia
    NIM         : 2201091003
    Deskripsi   : Harga susu
*/
#include "stdio.h"
void main()
{
    int susu_x,susu_y,susu_z,totalitem;
    long int a,b,diskon,total,pajak,setpajak,totalbeli,hargaz,hargay,hargax,uang,kembalian;

    printf("jumlah pembelian susu x =");
    scanf("%i", &susu_x);
    printf("jumlah pembelian susu y =");
    scanf("%i", &susu_y);
    printf("jumlah pembelian susu z =");
    scanf("%i", &susu_z);

    if (susu_x >2)
    {
        a=2*45000;
        b=(susu_x-2)*45000;
        hargax=a+b;
        diskon=0.05*b;
        total=hargax-diskon;
    }
    else
    {
        hargax=susu_x*45000;
        diskon=0;
        total=hargax-diskon;
    }printf("\nharga susu x sebelum diskon \t=%li", hargax);
    printf("\ntotal diskon susu x\t\t=%li", diskon);
    printf("\nharga susu x setelah diskon\t=%li", total);
    if (susu_y >3)
    {
        hargay=susu_y* 65000;
        diskon=0.1*hargay;
        total=hargay-diskon;
    }
    else
    {
        hargay=susu_y*65000;
        diskon=0;
        total=hargay-diskon;
    }printf("\nharga susu y sebelum diskon \t=%li", hargay);
    printf("\ntotal diskon susu y\t\t=%li", diskon);
    printf("\nharga susu y setelah diskon\t=%li", total);
    if (susu_z >5)
    {
        hargaz=susu_z* 90000;
        diskon=0.15*hargaz;
        total=hargaz-diskon;
    }
    else
    {
        hargaz=susu_z*95000;
        diskon=0;
        total=hargaz-diskon;
    }printf("\nharga susu z sebelum diskon \t=%li", hargaz);
    printf("\ntotal diskon susu z\t\t=%li", diskon);
    printf("\nharga susu z setelah diskon\t=%li", total);
    totalitem=susu_x+susu_y+susu_z;
    totalbeli=hargax+hargay+hargaz;
    pajak=0.1*totalbeli;
    setpajak=totalbeli+pajak;
    printf("\njumlah susu yang dibeli\t\t=%i", totalitem);
    printf("\ntotal harga sebelum pajak\t=%li", totalbeli);
    printf("\npajak\t\t\t\t=%li", pajak);
    printf("\ntotal harga setelah pajak\t=%li", setpajak);

    printf("\nuang anda\t\t\t=");
    scanf("%li", &uang);
    if (uang>=setpajak)
    {
        kembalian=uang-setpajak;
        printf("kembalian uang anda \t\t=%li", kembalian);
    }
    else
    {
        kembalian=uang-setpajak;
        printf("\nuang anda kurang\t\t =%li", kembalian);
    }





}
