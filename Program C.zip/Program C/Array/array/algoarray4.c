
#include <stdio.h>

void main()
{
    int a[10],b[10];
    int i,n,j;
    printf ("masukkan batas array = ");
    scanf ("%i",&n);
    for (i=0;i<n;i++)
    {
        printf ("masukan nilai array indeks ke %i = ",i);
        scanf  ("%i",&a[i]);
    }
    printf ("\nisi array a : ");
    for (i=0;i<n;i++)
    {
        printf (" %i ",a[i]);
    }
    j=0;
    for (i=0;i<n;i++)
    {
        if(i%2==0)
        {
            b[j]=a[i];
            j++;
        }
    }
    printf("\nisi array b : ");
    for (i=0;i<j+1;i++)
    {
        printf (" %i ",b[i]);
    }


}

