/** Nama        : Basmida Laia
    NIM         : 2201091003
*/
#include "stdio.h"

void main()
{
    int i,j,b,k;

    printf("masukkan baris =");
    scanf("%i", &b);
    printf("masukkan kolom =");
    scanf("%i", &k);

    for (i=1;i<=b;i++)
    {
        for (j=1;j<=i;j++)
        {
            if (i%2==1)
            {
                printf("%i", i);
            }
            else
            {
                printf("%i", j);
            }
        }

    }
}
