/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: array
**/

#include "stdio.h"

void main()
{
    int kelas[10];
    int i,total,ulang,nmak,nmin;
    float rata;

    do
    {
    total=0;
    nmak=-999;
    nmin=999;
    for(i=0;i<10;i++)
    {
        printf("masukkan angka ke-%i = ",i+1);
        scanf("%i",&kelas[i]);
        total =total+kelas[i];
        if(kelas[i]>nmak)
        {
            nmak=kelas[i];
        }
        if(kelas[i]<nmin)
        {
            nmin=kelas[i];
        }

    }
    printf("\nnilai Dari Array kelas adalah : ");

    for(i=0;i<10;i++)
    {
        printf(" %i ",kelas[i]);


    }

        if(kelas[i]>nmak)
        {
            nmak=kelas[i];
        }
        if(kelas[i]<nmin)
        {
            nmin=kelas[i];
        }

        printf("\ntotal kidz: %i ",total);
        rata=(float)total/10;
        printf("\nrata kidz: %.1f ",rata);
        printf("\nnilai max=%i",nmak);
        printf("\nnilai min=%i",nmin);


    printf("\nulang kah kidz=");
    scanf("%i",&ulang);
    system("cls");
    }while(ulang==1 || ulang==0);

}

