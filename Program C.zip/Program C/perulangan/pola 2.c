/** Nama        : Linus dimbau
    NIM         : 2201091008
    Deskripsi   : pola 1

    5 4 3 2 1
    5 4 3 2 1
    5 4 3 2 1
    5 4 3 2 1
*/
#include "stdio.h"
void main ()
{
    int i,j,b,k;

    printf("Masukkan jumlah baris =");
    scanf("%i", &b);
    printf("Masukkan jumlah kolom =");
    scanf("%i", &k);

    for (i=1;i<=b;i++)
    {
        for (j=k;j>=1;j--)
        {
            printf(" %i ", j);
        }
        printf("\n");
    }

}
