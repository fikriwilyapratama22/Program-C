/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: while
**/

#include "stdio.h"

void main()
{
    int a,b,c,j,i,k;





    printf("jumlah baris=");
    scanf("%i",&k);
    a=0;
    b=1;
    printf(" %i",a);
    printf(" %i",b);

    i=0;
    while(i<=k)
    {


    c=a+b;
    printf(" %i ", c);
    a=b;
    b=c;
    i=i+1;
    }
    }














