/** Nama: Fikri Wilya Pratama
    NIM: 2201091017
    Deskripsi: iterasi faktorial permutasi kombinasi
**/

#include "stdio.h"

void main()
{
    int i,j,b,k,a;

    printf("jumlah baris=");
    scanf("%i",&b);
    printf("jumlah klm=");
    scanf("%i",&k);


    for(i=1;i<=b;i++)
    {


        for(j=1;j<=k;j++)
        {
            if (i%4==1)
            {
                printf("$");
            }
            else if (i%4==2)
            {
                printf("*");
            }
            else if (i%4==3)
            {
                printf("#");
            }
            else if(i%4==0)
            {
                printf("0");
            }





        }
        printf(" \n ");


    }
}

